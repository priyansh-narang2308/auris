
/**
 * Client
**/

import * as runtime from './runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model SlackInstallation
 * 
 */
export type SlackInstallation = $Result.DefaultSelection<Prisma.$SlackInstallationPayload>
/**
 * Model Meeting
 * 
 */
export type Meeting = $Result.DefaultSelection<Prisma.$MeetingPayload>
/**
 * Model UserIntegration
 * 
 */
export type UserIntegration = $Result.DefaultSelection<Prisma.$UserIntegrationPayload>
/**
 * Model TranscriptChunk
 * 
 */
export type TranscriptChunk = $Result.DefaultSelection<Prisma.$TranscriptChunkPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.slackInstallation`: Exposes CRUD operations for the **SlackInstallation** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SlackInstallations
    * const slackInstallations = await prisma.slackInstallation.findMany()
    * ```
    */
  get slackInstallation(): Prisma.SlackInstallationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.meeting`: Exposes CRUD operations for the **Meeting** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Meetings
    * const meetings = await prisma.meeting.findMany()
    * ```
    */
  get meeting(): Prisma.MeetingDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.userIntegration`: Exposes CRUD operations for the **UserIntegration** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UserIntegrations
    * const userIntegrations = await prisma.userIntegration.findMany()
    * ```
    */
  get userIntegration(): Prisma.UserIntegrationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.transcriptChunk`: Exposes CRUD operations for the **TranscriptChunk** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TranscriptChunks
    * const transcriptChunks = await prisma.transcriptChunk.findMany()
    * ```
    */
  get transcriptChunk(): Prisma.TranscriptChunkDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.3.0
   * Query Engine version: 9d6ad21cbbceab97458517b147a6a09ff43aa735
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    SlackInstallation: 'SlackInstallation',
    Meeting: 'Meeting',
    UserIntegration: 'UserIntegration',
    TranscriptChunk: 'TranscriptChunk'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "slackInstallation" | "meeting" | "userIntegration" | "transcriptChunk"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      SlackInstallation: {
        payload: Prisma.$SlackInstallationPayload<ExtArgs>
        fields: Prisma.SlackInstallationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SlackInstallationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SlackInstallationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>
          }
          findFirst: {
            args: Prisma.SlackInstallationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SlackInstallationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>
          }
          findMany: {
            args: Prisma.SlackInstallationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>[]
          }
          create: {
            args: Prisma.SlackInstallationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>
          }
          createMany: {
            args: Prisma.SlackInstallationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SlackInstallationCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>[]
          }
          delete: {
            args: Prisma.SlackInstallationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>
          }
          update: {
            args: Prisma.SlackInstallationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>
          }
          deleteMany: {
            args: Prisma.SlackInstallationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SlackInstallationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SlackInstallationUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>[]
          }
          upsert: {
            args: Prisma.SlackInstallationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlackInstallationPayload>
          }
          aggregate: {
            args: Prisma.SlackInstallationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSlackInstallation>
          }
          groupBy: {
            args: Prisma.SlackInstallationGroupByArgs<ExtArgs>
            result: $Utils.Optional<SlackInstallationGroupByOutputType>[]
          }
          count: {
            args: Prisma.SlackInstallationCountArgs<ExtArgs>
            result: $Utils.Optional<SlackInstallationCountAggregateOutputType> | number
          }
        }
      }
      Meeting: {
        payload: Prisma.$MeetingPayload<ExtArgs>
        fields: Prisma.MeetingFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MeetingFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MeetingFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>
          }
          findFirst: {
            args: Prisma.MeetingFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MeetingFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>
          }
          findMany: {
            args: Prisma.MeetingFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>[]
          }
          create: {
            args: Prisma.MeetingCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>
          }
          createMany: {
            args: Prisma.MeetingCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MeetingCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>[]
          }
          delete: {
            args: Prisma.MeetingDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>
          }
          update: {
            args: Prisma.MeetingUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>
          }
          deleteMany: {
            args: Prisma.MeetingDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MeetingUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MeetingUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>[]
          }
          upsert: {
            args: Prisma.MeetingUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MeetingPayload>
          }
          aggregate: {
            args: Prisma.MeetingAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMeeting>
          }
          groupBy: {
            args: Prisma.MeetingGroupByArgs<ExtArgs>
            result: $Utils.Optional<MeetingGroupByOutputType>[]
          }
          count: {
            args: Prisma.MeetingCountArgs<ExtArgs>
            result: $Utils.Optional<MeetingCountAggregateOutputType> | number
          }
        }
      }
      UserIntegration: {
        payload: Prisma.$UserIntegrationPayload<ExtArgs>
        fields: Prisma.UserIntegrationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserIntegrationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserIntegrationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>
          }
          findFirst: {
            args: Prisma.UserIntegrationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserIntegrationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>
          }
          findMany: {
            args: Prisma.UserIntegrationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>[]
          }
          create: {
            args: Prisma.UserIntegrationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>
          }
          createMany: {
            args: Prisma.UserIntegrationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserIntegrationCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>[]
          }
          delete: {
            args: Prisma.UserIntegrationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>
          }
          update: {
            args: Prisma.UserIntegrationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>
          }
          deleteMany: {
            args: Prisma.UserIntegrationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserIntegrationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserIntegrationUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>[]
          }
          upsert: {
            args: Prisma.UserIntegrationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserIntegrationPayload>
          }
          aggregate: {
            args: Prisma.UserIntegrationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUserIntegration>
          }
          groupBy: {
            args: Prisma.UserIntegrationGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserIntegrationGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserIntegrationCountArgs<ExtArgs>
            result: $Utils.Optional<UserIntegrationCountAggregateOutputType> | number
          }
        }
      }
      TranscriptChunk: {
        payload: Prisma.$TranscriptChunkPayload<ExtArgs>
        fields: Prisma.TranscriptChunkFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TranscriptChunkFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TranscriptChunkFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>
          }
          findFirst: {
            args: Prisma.TranscriptChunkFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TranscriptChunkFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>
          }
          findMany: {
            args: Prisma.TranscriptChunkFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>[]
          }
          create: {
            args: Prisma.TranscriptChunkCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>
          }
          createMany: {
            args: Prisma.TranscriptChunkCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.TranscriptChunkCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>[]
          }
          delete: {
            args: Prisma.TranscriptChunkDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>
          }
          update: {
            args: Prisma.TranscriptChunkUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>
          }
          deleteMany: {
            args: Prisma.TranscriptChunkDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TranscriptChunkUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.TranscriptChunkUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>[]
          }
          upsert: {
            args: Prisma.TranscriptChunkUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TranscriptChunkPayload>
          }
          aggregate: {
            args: Prisma.TranscriptChunkAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTranscriptChunk>
          }
          groupBy: {
            args: Prisma.TranscriptChunkGroupByArgs<ExtArgs>
            result: $Utils.Optional<TranscriptChunkGroupByOutputType>[]
          }
          count: {
            args: Prisma.TranscriptChunkCountArgs<ExtArgs>
            result: $Utils.Optional<TranscriptChunkCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    slackInstallation?: SlackInstallationOmit
    meeting?: MeetingOmit
    userIntegration?: UserIntegrationOmit
    transcriptChunk?: TranscriptChunkOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    meetings: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    meetings?: boolean | UserCountOutputTypeCountMeetingsArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountMeetingsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MeetingWhereInput
  }


  /**
   * Count Type MeetingCountOutputType
   */

  export type MeetingCountOutputType = {
    TranscriptChunk: number
  }

  export type MeetingCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    TranscriptChunk?: boolean | MeetingCountOutputTypeCountTranscriptChunkArgs
  }

  // Custom InputTypes
  /**
   * MeetingCountOutputType without action
   */
  export type MeetingCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MeetingCountOutputType
     */
    select?: MeetingCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * MeetingCountOutputType without action
   */
  export type MeetingCountOutputTypeCountTranscriptChunkArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TranscriptChunkWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserAvgAggregateOutputType = {
    meetingsThisMonth: number | null
    chatMessagesToday: number | null
  }

  export type UserSumAggregateOutputType = {
    meetingsThisMonth: number | null
    chatMessagesToday: number | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    clerkId: string | null
    email: string | null
    name: string | null
    botName: string | null
    botImageUrl: string | null
    googleAccessToken: string | null
    googleRefreshToken: string | null
    googleTokenExpiry: Date | null
    calendarConnected: boolean | null
    slackUserId: string | null
    slackTeamId: string | null
    slackConnected: boolean | null
    preferredChannelId: string | null
    preferredChannelName: string | null
    currentPlan: string | null
    subscriptionStatus: string | null
    stripeCustomerId: string | null
    stripeSubscriptionId: string | null
    billingPeriodStart: Date | null
    meetingsThisMonth: number | null
    chatMessagesToday: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    clerkId: string | null
    email: string | null
    name: string | null
    botName: string | null
    botImageUrl: string | null
    googleAccessToken: string | null
    googleRefreshToken: string | null
    googleTokenExpiry: Date | null
    calendarConnected: boolean | null
    slackUserId: string | null
    slackTeamId: string | null
    slackConnected: boolean | null
    preferredChannelId: string | null
    preferredChannelName: string | null
    currentPlan: string | null
    subscriptionStatus: string | null
    stripeCustomerId: string | null
    stripeSubscriptionId: string | null
    billingPeriodStart: Date | null
    meetingsThisMonth: number | null
    chatMessagesToday: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    clerkId: number
    email: number
    name: number
    botName: number
    botImageUrl: number
    googleAccessToken: number
    googleRefreshToken: number
    googleTokenExpiry: number
    calendarConnected: number
    slackUserId: number
    slackTeamId: number
    slackConnected: number
    preferredChannelId: number
    preferredChannelName: number
    currentPlan: number
    subscriptionStatus: number
    stripeCustomerId: number
    stripeSubscriptionId: number
    billingPeriodStart: number
    meetingsThisMonth: number
    chatMessagesToday: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserAvgAggregateInputType = {
    meetingsThisMonth?: true
    chatMessagesToday?: true
  }

  export type UserSumAggregateInputType = {
    meetingsThisMonth?: true
    chatMessagesToday?: true
  }

  export type UserMinAggregateInputType = {
    id?: true
    clerkId?: true
    email?: true
    name?: true
    botName?: true
    botImageUrl?: true
    googleAccessToken?: true
    googleRefreshToken?: true
    googleTokenExpiry?: true
    calendarConnected?: true
    slackUserId?: true
    slackTeamId?: true
    slackConnected?: true
    preferredChannelId?: true
    preferredChannelName?: true
    currentPlan?: true
    subscriptionStatus?: true
    stripeCustomerId?: true
    stripeSubscriptionId?: true
    billingPeriodStart?: true
    meetingsThisMonth?: true
    chatMessagesToday?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    clerkId?: true
    email?: true
    name?: true
    botName?: true
    botImageUrl?: true
    googleAccessToken?: true
    googleRefreshToken?: true
    googleTokenExpiry?: true
    calendarConnected?: true
    slackUserId?: true
    slackTeamId?: true
    slackConnected?: true
    preferredChannelId?: true
    preferredChannelName?: true
    currentPlan?: true
    subscriptionStatus?: true
    stripeCustomerId?: true
    stripeSubscriptionId?: true
    billingPeriodStart?: true
    meetingsThisMonth?: true
    chatMessagesToday?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    clerkId?: true
    email?: true
    name?: true
    botName?: true
    botImageUrl?: true
    googleAccessToken?: true
    googleRefreshToken?: true
    googleTokenExpiry?: true
    calendarConnected?: true
    slackUserId?: true
    slackTeamId?: true
    slackConnected?: true
    preferredChannelId?: true
    preferredChannelName?: true
    currentPlan?: true
    subscriptionStatus?: true
    stripeCustomerId?: true
    stripeSubscriptionId?: true
    billingPeriodStart?: true
    meetingsThisMonth?: true
    chatMessagesToday?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UserAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UserSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _avg?: UserAvgAggregateInputType
    _sum?: UserSumAggregateInputType
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    clerkId: string
    email: string | null
    name: string | null
    botName: string | null
    botImageUrl: string | null
    googleAccessToken: string | null
    googleRefreshToken: string | null
    googleTokenExpiry: Date | null
    calendarConnected: boolean
    slackUserId: string | null
    slackTeamId: string | null
    slackConnected: boolean
    preferredChannelId: string | null
    preferredChannelName: string | null
    currentPlan: string
    subscriptionStatus: string
    stripeCustomerId: string | null
    stripeSubscriptionId: string | null
    billingPeriodStart: Date | null
    meetingsThisMonth: number
    chatMessagesToday: number
    createdAt: Date
    updatedAt: Date
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    clerkId?: boolean
    email?: boolean
    name?: boolean
    botName?: boolean
    botImageUrl?: boolean
    googleAccessToken?: boolean
    googleRefreshToken?: boolean
    googleTokenExpiry?: boolean
    calendarConnected?: boolean
    slackUserId?: boolean
    slackTeamId?: boolean
    slackConnected?: boolean
    preferredChannelId?: boolean
    preferredChannelName?: boolean
    currentPlan?: boolean
    subscriptionStatus?: boolean
    stripeCustomerId?: boolean
    stripeSubscriptionId?: boolean
    billingPeriodStart?: boolean
    meetingsThisMonth?: boolean
    chatMessagesToday?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    meetings?: boolean | User$meetingsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    clerkId?: boolean
    email?: boolean
    name?: boolean
    botName?: boolean
    botImageUrl?: boolean
    googleAccessToken?: boolean
    googleRefreshToken?: boolean
    googleTokenExpiry?: boolean
    calendarConnected?: boolean
    slackUserId?: boolean
    slackTeamId?: boolean
    slackConnected?: boolean
    preferredChannelId?: boolean
    preferredChannelName?: boolean
    currentPlan?: boolean
    subscriptionStatus?: boolean
    stripeCustomerId?: boolean
    stripeSubscriptionId?: boolean
    billingPeriodStart?: boolean
    meetingsThisMonth?: boolean
    chatMessagesToday?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    clerkId?: boolean
    email?: boolean
    name?: boolean
    botName?: boolean
    botImageUrl?: boolean
    googleAccessToken?: boolean
    googleRefreshToken?: boolean
    googleTokenExpiry?: boolean
    calendarConnected?: boolean
    slackUserId?: boolean
    slackTeamId?: boolean
    slackConnected?: boolean
    preferredChannelId?: boolean
    preferredChannelName?: boolean
    currentPlan?: boolean
    subscriptionStatus?: boolean
    stripeCustomerId?: boolean
    stripeSubscriptionId?: boolean
    billingPeriodStart?: boolean
    meetingsThisMonth?: boolean
    chatMessagesToday?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    clerkId?: boolean
    email?: boolean
    name?: boolean
    botName?: boolean
    botImageUrl?: boolean
    googleAccessToken?: boolean
    googleRefreshToken?: boolean
    googleTokenExpiry?: boolean
    calendarConnected?: boolean
    slackUserId?: boolean
    slackTeamId?: boolean
    slackConnected?: boolean
    preferredChannelId?: boolean
    preferredChannelName?: boolean
    currentPlan?: boolean
    subscriptionStatus?: boolean
    stripeCustomerId?: boolean
    stripeSubscriptionId?: boolean
    billingPeriodStart?: boolean
    meetingsThisMonth?: boolean
    chatMessagesToday?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "clerkId" | "email" | "name" | "botName" | "botImageUrl" | "googleAccessToken" | "googleRefreshToken" | "googleTokenExpiry" | "calendarConnected" | "slackUserId" | "slackTeamId" | "slackConnected" | "preferredChannelId" | "preferredChannelName" | "currentPlan" | "subscriptionStatus" | "stripeCustomerId" | "stripeSubscriptionId" | "billingPeriodStart" | "meetingsThisMonth" | "chatMessagesToday" | "createdAt" | "updatedAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    meetings?: boolean | User$meetingsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type UserIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type UserIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      meetings: Prisma.$MeetingPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      clerkId: string
      email: string | null
      name: string | null
      botName: string | null
      botImageUrl: string | null
      googleAccessToken: string | null
      googleRefreshToken: string | null
      googleTokenExpiry: Date | null
      calendarConnected: boolean
      slackUserId: string | null
      slackTeamId: string | null
      slackConnected: boolean
      preferredChannelId: string | null
      preferredChannelName: string | null
      currentPlan: string
      subscriptionStatus: string
      stripeCustomerId: string | null
      stripeSubscriptionId: string | null
      billingPeriodStart: Date | null
      meetingsThisMonth: number
      chatMessagesToday: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    meetings<T extends User$meetingsArgs<ExtArgs> = {}>(args?: Subset<T, User$meetingsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly clerkId: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly botName: FieldRef<"User", 'String'>
    readonly botImageUrl: FieldRef<"User", 'String'>
    readonly googleAccessToken: FieldRef<"User", 'String'>
    readonly googleRefreshToken: FieldRef<"User", 'String'>
    readonly googleTokenExpiry: FieldRef<"User", 'DateTime'>
    readonly calendarConnected: FieldRef<"User", 'Boolean'>
    readonly slackUserId: FieldRef<"User", 'String'>
    readonly slackTeamId: FieldRef<"User", 'String'>
    readonly slackConnected: FieldRef<"User", 'Boolean'>
    readonly preferredChannelId: FieldRef<"User", 'String'>
    readonly preferredChannelName: FieldRef<"User", 'String'>
    readonly currentPlan: FieldRef<"User", 'String'>
    readonly subscriptionStatus: FieldRef<"User", 'String'>
    readonly stripeCustomerId: FieldRef<"User", 'String'>
    readonly stripeSubscriptionId: FieldRef<"User", 'String'>
    readonly billingPeriodStart: FieldRef<"User", 'DateTime'>
    readonly meetingsThisMonth: FieldRef<"User", 'Int'>
    readonly chatMessagesToday: FieldRef<"User", 'Int'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly updatedAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.meetings
   */
  export type User$meetingsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    where?: MeetingWhereInput
    orderBy?: MeetingOrderByWithRelationInput | MeetingOrderByWithRelationInput[]
    cursor?: MeetingWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MeetingScalarFieldEnum | MeetingScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model SlackInstallation
   */

  export type AggregateSlackInstallation = {
    _count: SlackInstallationCountAggregateOutputType | null
    _min: SlackInstallationMinAggregateOutputType | null
    _max: SlackInstallationMaxAggregateOutputType | null
  }

  export type SlackInstallationMinAggregateOutputType = {
    id: string | null
    teamId: string | null
    teamName: string | null
    botToken: string | null
    installedBy: string | null
    installerName: string | null
    active: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SlackInstallationMaxAggregateOutputType = {
    id: string | null
    teamId: string | null
    teamName: string | null
    botToken: string | null
    installedBy: string | null
    installerName: string | null
    active: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SlackInstallationCountAggregateOutputType = {
    id: number
    teamId: number
    teamName: number
    botToken: number
    installedBy: number
    installerName: number
    active: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SlackInstallationMinAggregateInputType = {
    id?: true
    teamId?: true
    teamName?: true
    botToken?: true
    installedBy?: true
    installerName?: true
    active?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SlackInstallationMaxAggregateInputType = {
    id?: true
    teamId?: true
    teamName?: true
    botToken?: true
    installedBy?: true
    installerName?: true
    active?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SlackInstallationCountAggregateInputType = {
    id?: true
    teamId?: true
    teamName?: true
    botToken?: true
    installedBy?: true
    installerName?: true
    active?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SlackInstallationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SlackInstallation to aggregate.
     */
    where?: SlackInstallationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlackInstallations to fetch.
     */
    orderBy?: SlackInstallationOrderByWithRelationInput | SlackInstallationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SlackInstallationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlackInstallations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlackInstallations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SlackInstallations
    **/
    _count?: true | SlackInstallationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SlackInstallationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SlackInstallationMaxAggregateInputType
  }

  export type GetSlackInstallationAggregateType<T extends SlackInstallationAggregateArgs> = {
        [P in keyof T & keyof AggregateSlackInstallation]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSlackInstallation[P]>
      : GetScalarType<T[P], AggregateSlackInstallation[P]>
  }




  export type SlackInstallationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SlackInstallationWhereInput
    orderBy?: SlackInstallationOrderByWithAggregationInput | SlackInstallationOrderByWithAggregationInput[]
    by: SlackInstallationScalarFieldEnum[] | SlackInstallationScalarFieldEnum
    having?: SlackInstallationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SlackInstallationCountAggregateInputType | true
    _min?: SlackInstallationMinAggregateInputType
    _max?: SlackInstallationMaxAggregateInputType
  }

  export type SlackInstallationGroupByOutputType = {
    id: string
    teamId: string
    teamName: string
    botToken: string
    installedBy: string
    installerName: string | null
    active: boolean
    createdAt: Date
    updatedAt: Date
    _count: SlackInstallationCountAggregateOutputType | null
    _min: SlackInstallationMinAggregateOutputType | null
    _max: SlackInstallationMaxAggregateOutputType | null
  }

  type GetSlackInstallationGroupByPayload<T extends SlackInstallationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SlackInstallationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SlackInstallationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SlackInstallationGroupByOutputType[P]>
            : GetScalarType<T[P], SlackInstallationGroupByOutputType[P]>
        }
      >
    >


  export type SlackInstallationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    teamId?: boolean
    teamName?: boolean
    botToken?: boolean
    installedBy?: boolean
    installerName?: boolean
    active?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["slackInstallation"]>

  export type SlackInstallationSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    teamId?: boolean
    teamName?: boolean
    botToken?: boolean
    installedBy?: boolean
    installerName?: boolean
    active?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["slackInstallation"]>

  export type SlackInstallationSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    teamId?: boolean
    teamName?: boolean
    botToken?: boolean
    installedBy?: boolean
    installerName?: boolean
    active?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["slackInstallation"]>

  export type SlackInstallationSelectScalar = {
    id?: boolean
    teamId?: boolean
    teamName?: boolean
    botToken?: boolean
    installedBy?: boolean
    installerName?: boolean
    active?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SlackInstallationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "teamId" | "teamName" | "botToken" | "installedBy" | "installerName" | "active" | "createdAt" | "updatedAt", ExtArgs["result"]["slackInstallation"]>

  export type $SlackInstallationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SlackInstallation"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      teamId: string
      teamName: string
      botToken: string
      installedBy: string
      installerName: string | null
      active: boolean
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["slackInstallation"]>
    composites: {}
  }

  type SlackInstallationGetPayload<S extends boolean | null | undefined | SlackInstallationDefaultArgs> = $Result.GetResult<Prisma.$SlackInstallationPayload, S>

  type SlackInstallationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SlackInstallationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SlackInstallationCountAggregateInputType | true
    }

  export interface SlackInstallationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SlackInstallation'], meta: { name: 'SlackInstallation' } }
    /**
     * Find zero or one SlackInstallation that matches the filter.
     * @param {SlackInstallationFindUniqueArgs} args - Arguments to find a SlackInstallation
     * @example
     * // Get one SlackInstallation
     * const slackInstallation = await prisma.slackInstallation.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SlackInstallationFindUniqueArgs>(args: SelectSubset<T, SlackInstallationFindUniqueArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SlackInstallation that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SlackInstallationFindUniqueOrThrowArgs} args - Arguments to find a SlackInstallation
     * @example
     * // Get one SlackInstallation
     * const slackInstallation = await prisma.slackInstallation.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SlackInstallationFindUniqueOrThrowArgs>(args: SelectSubset<T, SlackInstallationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SlackInstallation that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlackInstallationFindFirstArgs} args - Arguments to find a SlackInstallation
     * @example
     * // Get one SlackInstallation
     * const slackInstallation = await prisma.slackInstallation.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SlackInstallationFindFirstArgs>(args?: SelectSubset<T, SlackInstallationFindFirstArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SlackInstallation that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlackInstallationFindFirstOrThrowArgs} args - Arguments to find a SlackInstallation
     * @example
     * // Get one SlackInstallation
     * const slackInstallation = await prisma.slackInstallation.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SlackInstallationFindFirstOrThrowArgs>(args?: SelectSubset<T, SlackInstallationFindFirstOrThrowArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SlackInstallations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlackInstallationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SlackInstallations
     * const slackInstallations = await prisma.slackInstallation.findMany()
     * 
     * // Get first 10 SlackInstallations
     * const slackInstallations = await prisma.slackInstallation.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const slackInstallationWithIdOnly = await prisma.slackInstallation.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SlackInstallationFindManyArgs>(args?: SelectSubset<T, SlackInstallationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SlackInstallation.
     * @param {SlackInstallationCreateArgs} args - Arguments to create a SlackInstallation.
     * @example
     * // Create one SlackInstallation
     * const SlackInstallation = await prisma.slackInstallation.create({
     *   data: {
     *     // ... data to create a SlackInstallation
     *   }
     * })
     * 
     */
    create<T extends SlackInstallationCreateArgs>(args: SelectSubset<T, SlackInstallationCreateArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SlackInstallations.
     * @param {SlackInstallationCreateManyArgs} args - Arguments to create many SlackInstallations.
     * @example
     * // Create many SlackInstallations
     * const slackInstallation = await prisma.slackInstallation.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SlackInstallationCreateManyArgs>(args?: SelectSubset<T, SlackInstallationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many SlackInstallations and returns the data saved in the database.
     * @param {SlackInstallationCreateManyAndReturnArgs} args - Arguments to create many SlackInstallations.
     * @example
     * // Create many SlackInstallations
     * const slackInstallation = await prisma.slackInstallation.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many SlackInstallations and only return the `id`
     * const slackInstallationWithIdOnly = await prisma.slackInstallation.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SlackInstallationCreateManyAndReturnArgs>(args?: SelectSubset<T, SlackInstallationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a SlackInstallation.
     * @param {SlackInstallationDeleteArgs} args - Arguments to delete one SlackInstallation.
     * @example
     * // Delete one SlackInstallation
     * const SlackInstallation = await prisma.slackInstallation.delete({
     *   where: {
     *     // ... filter to delete one SlackInstallation
     *   }
     * })
     * 
     */
    delete<T extends SlackInstallationDeleteArgs>(args: SelectSubset<T, SlackInstallationDeleteArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SlackInstallation.
     * @param {SlackInstallationUpdateArgs} args - Arguments to update one SlackInstallation.
     * @example
     * // Update one SlackInstallation
     * const slackInstallation = await prisma.slackInstallation.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SlackInstallationUpdateArgs>(args: SelectSubset<T, SlackInstallationUpdateArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SlackInstallations.
     * @param {SlackInstallationDeleteManyArgs} args - Arguments to filter SlackInstallations to delete.
     * @example
     * // Delete a few SlackInstallations
     * const { count } = await prisma.slackInstallation.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SlackInstallationDeleteManyArgs>(args?: SelectSubset<T, SlackInstallationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SlackInstallations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlackInstallationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SlackInstallations
     * const slackInstallation = await prisma.slackInstallation.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SlackInstallationUpdateManyArgs>(args: SelectSubset<T, SlackInstallationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SlackInstallations and returns the data updated in the database.
     * @param {SlackInstallationUpdateManyAndReturnArgs} args - Arguments to update many SlackInstallations.
     * @example
     * // Update many SlackInstallations
     * const slackInstallation = await prisma.slackInstallation.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more SlackInstallations and only return the `id`
     * const slackInstallationWithIdOnly = await prisma.slackInstallation.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SlackInstallationUpdateManyAndReturnArgs>(args: SelectSubset<T, SlackInstallationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one SlackInstallation.
     * @param {SlackInstallationUpsertArgs} args - Arguments to update or create a SlackInstallation.
     * @example
     * // Update or create a SlackInstallation
     * const slackInstallation = await prisma.slackInstallation.upsert({
     *   create: {
     *     // ... data to create a SlackInstallation
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SlackInstallation we want to update
     *   }
     * })
     */
    upsert<T extends SlackInstallationUpsertArgs>(args: SelectSubset<T, SlackInstallationUpsertArgs<ExtArgs>>): Prisma__SlackInstallationClient<$Result.GetResult<Prisma.$SlackInstallationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SlackInstallations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlackInstallationCountArgs} args - Arguments to filter SlackInstallations to count.
     * @example
     * // Count the number of SlackInstallations
     * const count = await prisma.slackInstallation.count({
     *   where: {
     *     // ... the filter for the SlackInstallations we want to count
     *   }
     * })
    **/
    count<T extends SlackInstallationCountArgs>(
      args?: Subset<T, SlackInstallationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SlackInstallationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SlackInstallation.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlackInstallationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SlackInstallationAggregateArgs>(args: Subset<T, SlackInstallationAggregateArgs>): Prisma.PrismaPromise<GetSlackInstallationAggregateType<T>>

    /**
     * Group by SlackInstallation.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlackInstallationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SlackInstallationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SlackInstallationGroupByArgs['orderBy'] }
        : { orderBy?: SlackInstallationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SlackInstallationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSlackInstallationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SlackInstallation model
   */
  readonly fields: SlackInstallationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SlackInstallation.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SlackInstallationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SlackInstallation model
   */
  interface SlackInstallationFieldRefs {
    readonly id: FieldRef<"SlackInstallation", 'String'>
    readonly teamId: FieldRef<"SlackInstallation", 'String'>
    readonly teamName: FieldRef<"SlackInstallation", 'String'>
    readonly botToken: FieldRef<"SlackInstallation", 'String'>
    readonly installedBy: FieldRef<"SlackInstallation", 'String'>
    readonly installerName: FieldRef<"SlackInstallation", 'String'>
    readonly active: FieldRef<"SlackInstallation", 'Boolean'>
    readonly createdAt: FieldRef<"SlackInstallation", 'DateTime'>
    readonly updatedAt: FieldRef<"SlackInstallation", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SlackInstallation findUnique
   */
  export type SlackInstallationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * Filter, which SlackInstallation to fetch.
     */
    where: SlackInstallationWhereUniqueInput
  }

  /**
   * SlackInstallation findUniqueOrThrow
   */
  export type SlackInstallationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * Filter, which SlackInstallation to fetch.
     */
    where: SlackInstallationWhereUniqueInput
  }

  /**
   * SlackInstallation findFirst
   */
  export type SlackInstallationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * Filter, which SlackInstallation to fetch.
     */
    where?: SlackInstallationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlackInstallations to fetch.
     */
    orderBy?: SlackInstallationOrderByWithRelationInput | SlackInstallationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SlackInstallations.
     */
    cursor?: SlackInstallationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlackInstallations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlackInstallations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SlackInstallations.
     */
    distinct?: SlackInstallationScalarFieldEnum | SlackInstallationScalarFieldEnum[]
  }

  /**
   * SlackInstallation findFirstOrThrow
   */
  export type SlackInstallationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * Filter, which SlackInstallation to fetch.
     */
    where?: SlackInstallationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlackInstallations to fetch.
     */
    orderBy?: SlackInstallationOrderByWithRelationInput | SlackInstallationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SlackInstallations.
     */
    cursor?: SlackInstallationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlackInstallations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlackInstallations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SlackInstallations.
     */
    distinct?: SlackInstallationScalarFieldEnum | SlackInstallationScalarFieldEnum[]
  }

  /**
   * SlackInstallation findMany
   */
  export type SlackInstallationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * Filter, which SlackInstallations to fetch.
     */
    where?: SlackInstallationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlackInstallations to fetch.
     */
    orderBy?: SlackInstallationOrderByWithRelationInput | SlackInstallationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SlackInstallations.
     */
    cursor?: SlackInstallationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlackInstallations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlackInstallations.
     */
    skip?: number
    distinct?: SlackInstallationScalarFieldEnum | SlackInstallationScalarFieldEnum[]
  }

  /**
   * SlackInstallation create
   */
  export type SlackInstallationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * The data needed to create a SlackInstallation.
     */
    data: XOR<SlackInstallationCreateInput, SlackInstallationUncheckedCreateInput>
  }

  /**
   * SlackInstallation createMany
   */
  export type SlackInstallationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SlackInstallations.
     */
    data: SlackInstallationCreateManyInput | SlackInstallationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SlackInstallation createManyAndReturn
   */
  export type SlackInstallationCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * The data used to create many SlackInstallations.
     */
    data: SlackInstallationCreateManyInput | SlackInstallationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SlackInstallation update
   */
  export type SlackInstallationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * The data needed to update a SlackInstallation.
     */
    data: XOR<SlackInstallationUpdateInput, SlackInstallationUncheckedUpdateInput>
    /**
     * Choose, which SlackInstallation to update.
     */
    where: SlackInstallationWhereUniqueInput
  }

  /**
   * SlackInstallation updateMany
   */
  export type SlackInstallationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SlackInstallations.
     */
    data: XOR<SlackInstallationUpdateManyMutationInput, SlackInstallationUncheckedUpdateManyInput>
    /**
     * Filter which SlackInstallations to update
     */
    where?: SlackInstallationWhereInput
    /**
     * Limit how many SlackInstallations to update.
     */
    limit?: number
  }

  /**
   * SlackInstallation updateManyAndReturn
   */
  export type SlackInstallationUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * The data used to update SlackInstallations.
     */
    data: XOR<SlackInstallationUpdateManyMutationInput, SlackInstallationUncheckedUpdateManyInput>
    /**
     * Filter which SlackInstallations to update
     */
    where?: SlackInstallationWhereInput
    /**
     * Limit how many SlackInstallations to update.
     */
    limit?: number
  }

  /**
   * SlackInstallation upsert
   */
  export type SlackInstallationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * The filter to search for the SlackInstallation to update in case it exists.
     */
    where: SlackInstallationWhereUniqueInput
    /**
     * In case the SlackInstallation found by the `where` argument doesn't exist, create a new SlackInstallation with this data.
     */
    create: XOR<SlackInstallationCreateInput, SlackInstallationUncheckedCreateInput>
    /**
     * In case the SlackInstallation was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SlackInstallationUpdateInput, SlackInstallationUncheckedUpdateInput>
  }

  /**
   * SlackInstallation delete
   */
  export type SlackInstallationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
    /**
     * Filter which SlackInstallation to delete.
     */
    where: SlackInstallationWhereUniqueInput
  }

  /**
   * SlackInstallation deleteMany
   */
  export type SlackInstallationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SlackInstallations to delete
     */
    where?: SlackInstallationWhereInput
    /**
     * Limit how many SlackInstallations to delete.
     */
    limit?: number
  }

  /**
   * SlackInstallation without action
   */
  export type SlackInstallationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlackInstallation
     */
    select?: SlackInstallationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlackInstallation
     */
    omit?: SlackInstallationOmit<ExtArgs> | null
  }


  /**
   * Model Meeting
   */

  export type AggregateMeeting = {
    _count: MeetingCountAggregateOutputType | null
    _min: MeetingMinAggregateOutputType | null
    _max: MeetingMaxAggregateOutputType | null
  }

  export type MeetingMinAggregateOutputType = {
    id: string | null
    userId: string | null
    title: string | null
    description: string | null
    meetingUrl: string | null
    startTime: Date | null
    endTime: Date | null
    calendarEventId: string | null
    isFromCalendar: boolean | null
    botScheduled: boolean | null
    botSent: boolean | null
    botId: string | null
    botJoinedAt: Date | null
    meetingEnded: boolean | null
    transcriptReady: boolean | null
    recordingUrl: string | null
    summary: string | null
    processed: boolean | null
    processedAt: Date | null
    emailSent: boolean | null
    emailSentAt: Date | null
    ragProcessed: boolean | null
    ragProcessedAt: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MeetingMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    title: string | null
    description: string | null
    meetingUrl: string | null
    startTime: Date | null
    endTime: Date | null
    calendarEventId: string | null
    isFromCalendar: boolean | null
    botScheduled: boolean | null
    botSent: boolean | null
    botId: string | null
    botJoinedAt: Date | null
    meetingEnded: boolean | null
    transcriptReady: boolean | null
    recordingUrl: string | null
    summary: string | null
    processed: boolean | null
    processedAt: Date | null
    emailSent: boolean | null
    emailSentAt: Date | null
    ragProcessed: boolean | null
    ragProcessedAt: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MeetingCountAggregateOutputType = {
    id: number
    userId: number
    title: number
    description: number
    meetingUrl: number
    startTime: number
    endTime: number
    attendees: number
    calendarEventId: number
    isFromCalendar: number
    botScheduled: number
    botSent: number
    botId: number
    botJoinedAt: number
    meetingEnded: number
    transcriptReady: number
    transcript: number
    recordingUrl: number
    speakers: number
    summary: number
    actionItems: number
    processed: number
    processedAt: number
    emailSent: number
    emailSentAt: number
    ragProcessed: number
    ragProcessedAt: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type MeetingMinAggregateInputType = {
    id?: true
    userId?: true
    title?: true
    description?: true
    meetingUrl?: true
    startTime?: true
    endTime?: true
    calendarEventId?: true
    isFromCalendar?: true
    botScheduled?: true
    botSent?: true
    botId?: true
    botJoinedAt?: true
    meetingEnded?: true
    transcriptReady?: true
    recordingUrl?: true
    summary?: true
    processed?: true
    processedAt?: true
    emailSent?: true
    emailSentAt?: true
    ragProcessed?: true
    ragProcessedAt?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MeetingMaxAggregateInputType = {
    id?: true
    userId?: true
    title?: true
    description?: true
    meetingUrl?: true
    startTime?: true
    endTime?: true
    calendarEventId?: true
    isFromCalendar?: true
    botScheduled?: true
    botSent?: true
    botId?: true
    botJoinedAt?: true
    meetingEnded?: true
    transcriptReady?: true
    recordingUrl?: true
    summary?: true
    processed?: true
    processedAt?: true
    emailSent?: true
    emailSentAt?: true
    ragProcessed?: true
    ragProcessedAt?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MeetingCountAggregateInputType = {
    id?: true
    userId?: true
    title?: true
    description?: true
    meetingUrl?: true
    startTime?: true
    endTime?: true
    attendees?: true
    calendarEventId?: true
    isFromCalendar?: true
    botScheduled?: true
    botSent?: true
    botId?: true
    botJoinedAt?: true
    meetingEnded?: true
    transcriptReady?: true
    transcript?: true
    recordingUrl?: true
    speakers?: true
    summary?: true
    actionItems?: true
    processed?: true
    processedAt?: true
    emailSent?: true
    emailSentAt?: true
    ragProcessed?: true
    ragProcessedAt?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type MeetingAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Meeting to aggregate.
     */
    where?: MeetingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Meetings to fetch.
     */
    orderBy?: MeetingOrderByWithRelationInput | MeetingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MeetingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Meetings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Meetings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Meetings
    **/
    _count?: true | MeetingCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MeetingMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MeetingMaxAggregateInputType
  }

  export type GetMeetingAggregateType<T extends MeetingAggregateArgs> = {
        [P in keyof T & keyof AggregateMeeting]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMeeting[P]>
      : GetScalarType<T[P], AggregateMeeting[P]>
  }




  export type MeetingGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MeetingWhereInput
    orderBy?: MeetingOrderByWithAggregationInput | MeetingOrderByWithAggregationInput[]
    by: MeetingScalarFieldEnum[] | MeetingScalarFieldEnum
    having?: MeetingScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MeetingCountAggregateInputType | true
    _min?: MeetingMinAggregateInputType
    _max?: MeetingMaxAggregateInputType
  }

  export type MeetingGroupByOutputType = {
    id: string
    userId: string
    title: string
    description: string | null
    meetingUrl: string | null
    startTime: Date
    endTime: Date
    attendees: JsonValue | null
    calendarEventId: string | null
    isFromCalendar: boolean
    botScheduled: boolean
    botSent: boolean
    botId: string | null
    botJoinedAt: Date | null
    meetingEnded: boolean
    transcriptReady: boolean
    transcript: JsonValue | null
    recordingUrl: string | null
    speakers: JsonValue | null
    summary: string | null
    actionItems: JsonValue | null
    processed: boolean
    processedAt: Date | null
    emailSent: boolean
    emailSentAt: Date | null
    ragProcessed: boolean
    ragProcessedAt: Date | null
    createdAt: Date
    updatedAt: Date
    _count: MeetingCountAggregateOutputType | null
    _min: MeetingMinAggregateOutputType | null
    _max: MeetingMaxAggregateOutputType | null
  }

  type GetMeetingGroupByPayload<T extends MeetingGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MeetingGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MeetingGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MeetingGroupByOutputType[P]>
            : GetScalarType<T[P], MeetingGroupByOutputType[P]>
        }
      >
    >


  export type MeetingSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    title?: boolean
    description?: boolean
    meetingUrl?: boolean
    startTime?: boolean
    endTime?: boolean
    attendees?: boolean
    calendarEventId?: boolean
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: boolean
    botJoinedAt?: boolean
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: boolean
    recordingUrl?: boolean
    speakers?: boolean
    summary?: boolean
    actionItems?: boolean
    processed?: boolean
    processedAt?: boolean
    emailSent?: boolean
    emailSentAt?: boolean
    ragProcessed?: boolean
    ragProcessedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    TranscriptChunk?: boolean | Meeting$TranscriptChunkArgs<ExtArgs>
    _count?: boolean | MeetingCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["meeting"]>

  export type MeetingSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    title?: boolean
    description?: boolean
    meetingUrl?: boolean
    startTime?: boolean
    endTime?: boolean
    attendees?: boolean
    calendarEventId?: boolean
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: boolean
    botJoinedAt?: boolean
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: boolean
    recordingUrl?: boolean
    speakers?: boolean
    summary?: boolean
    actionItems?: boolean
    processed?: boolean
    processedAt?: boolean
    emailSent?: boolean
    emailSentAt?: boolean
    ragProcessed?: boolean
    ragProcessedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["meeting"]>

  export type MeetingSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    title?: boolean
    description?: boolean
    meetingUrl?: boolean
    startTime?: boolean
    endTime?: boolean
    attendees?: boolean
    calendarEventId?: boolean
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: boolean
    botJoinedAt?: boolean
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: boolean
    recordingUrl?: boolean
    speakers?: boolean
    summary?: boolean
    actionItems?: boolean
    processed?: boolean
    processedAt?: boolean
    emailSent?: boolean
    emailSentAt?: boolean
    ragProcessed?: boolean
    ragProcessedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["meeting"]>

  export type MeetingSelectScalar = {
    id?: boolean
    userId?: boolean
    title?: boolean
    description?: boolean
    meetingUrl?: boolean
    startTime?: boolean
    endTime?: boolean
    attendees?: boolean
    calendarEventId?: boolean
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: boolean
    botJoinedAt?: boolean
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: boolean
    recordingUrl?: boolean
    speakers?: boolean
    summary?: boolean
    actionItems?: boolean
    processed?: boolean
    processedAt?: boolean
    emailSent?: boolean
    emailSentAt?: boolean
    ragProcessed?: boolean
    ragProcessedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type MeetingOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "title" | "description" | "meetingUrl" | "startTime" | "endTime" | "attendees" | "calendarEventId" | "isFromCalendar" | "botScheduled" | "botSent" | "botId" | "botJoinedAt" | "meetingEnded" | "transcriptReady" | "transcript" | "recordingUrl" | "speakers" | "summary" | "actionItems" | "processed" | "processedAt" | "emailSent" | "emailSentAt" | "ragProcessed" | "ragProcessedAt" | "createdAt" | "updatedAt", ExtArgs["result"]["meeting"]>
  export type MeetingInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    TranscriptChunk?: boolean | Meeting$TranscriptChunkArgs<ExtArgs>
    _count?: boolean | MeetingCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type MeetingIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type MeetingIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $MeetingPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Meeting"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      TranscriptChunk: Prisma.$TranscriptChunkPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      title: string
      description: string | null
      meetingUrl: string | null
      startTime: Date
      endTime: Date
      attendees: Prisma.JsonValue | null
      calendarEventId: string | null
      isFromCalendar: boolean
      botScheduled: boolean
      botSent: boolean
      botId: string | null
      botJoinedAt: Date | null
      meetingEnded: boolean
      transcriptReady: boolean
      transcript: Prisma.JsonValue | null
      recordingUrl: string | null
      speakers: Prisma.JsonValue | null
      summary: string | null
      actionItems: Prisma.JsonValue | null
      processed: boolean
      processedAt: Date | null
      emailSent: boolean
      emailSentAt: Date | null
      ragProcessed: boolean
      ragProcessedAt: Date | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["meeting"]>
    composites: {}
  }

  type MeetingGetPayload<S extends boolean | null | undefined | MeetingDefaultArgs> = $Result.GetResult<Prisma.$MeetingPayload, S>

  type MeetingCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MeetingFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MeetingCountAggregateInputType | true
    }

  export interface MeetingDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Meeting'], meta: { name: 'Meeting' } }
    /**
     * Find zero or one Meeting that matches the filter.
     * @param {MeetingFindUniqueArgs} args - Arguments to find a Meeting
     * @example
     * // Get one Meeting
     * const meeting = await prisma.meeting.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MeetingFindUniqueArgs>(args: SelectSubset<T, MeetingFindUniqueArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Meeting that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MeetingFindUniqueOrThrowArgs} args - Arguments to find a Meeting
     * @example
     * // Get one Meeting
     * const meeting = await prisma.meeting.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MeetingFindUniqueOrThrowArgs>(args: SelectSubset<T, MeetingFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Meeting that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MeetingFindFirstArgs} args - Arguments to find a Meeting
     * @example
     * // Get one Meeting
     * const meeting = await prisma.meeting.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MeetingFindFirstArgs>(args?: SelectSubset<T, MeetingFindFirstArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Meeting that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MeetingFindFirstOrThrowArgs} args - Arguments to find a Meeting
     * @example
     * // Get one Meeting
     * const meeting = await prisma.meeting.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MeetingFindFirstOrThrowArgs>(args?: SelectSubset<T, MeetingFindFirstOrThrowArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Meetings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MeetingFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Meetings
     * const meetings = await prisma.meeting.findMany()
     * 
     * // Get first 10 Meetings
     * const meetings = await prisma.meeting.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const meetingWithIdOnly = await prisma.meeting.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MeetingFindManyArgs>(args?: SelectSubset<T, MeetingFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Meeting.
     * @param {MeetingCreateArgs} args - Arguments to create a Meeting.
     * @example
     * // Create one Meeting
     * const Meeting = await prisma.meeting.create({
     *   data: {
     *     // ... data to create a Meeting
     *   }
     * })
     * 
     */
    create<T extends MeetingCreateArgs>(args: SelectSubset<T, MeetingCreateArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Meetings.
     * @param {MeetingCreateManyArgs} args - Arguments to create many Meetings.
     * @example
     * // Create many Meetings
     * const meeting = await prisma.meeting.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MeetingCreateManyArgs>(args?: SelectSubset<T, MeetingCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Meetings and returns the data saved in the database.
     * @param {MeetingCreateManyAndReturnArgs} args - Arguments to create many Meetings.
     * @example
     * // Create many Meetings
     * const meeting = await prisma.meeting.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Meetings and only return the `id`
     * const meetingWithIdOnly = await prisma.meeting.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MeetingCreateManyAndReturnArgs>(args?: SelectSubset<T, MeetingCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Meeting.
     * @param {MeetingDeleteArgs} args - Arguments to delete one Meeting.
     * @example
     * // Delete one Meeting
     * const Meeting = await prisma.meeting.delete({
     *   where: {
     *     // ... filter to delete one Meeting
     *   }
     * })
     * 
     */
    delete<T extends MeetingDeleteArgs>(args: SelectSubset<T, MeetingDeleteArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Meeting.
     * @param {MeetingUpdateArgs} args - Arguments to update one Meeting.
     * @example
     * // Update one Meeting
     * const meeting = await prisma.meeting.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MeetingUpdateArgs>(args: SelectSubset<T, MeetingUpdateArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Meetings.
     * @param {MeetingDeleteManyArgs} args - Arguments to filter Meetings to delete.
     * @example
     * // Delete a few Meetings
     * const { count } = await prisma.meeting.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MeetingDeleteManyArgs>(args?: SelectSubset<T, MeetingDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Meetings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MeetingUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Meetings
     * const meeting = await prisma.meeting.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MeetingUpdateManyArgs>(args: SelectSubset<T, MeetingUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Meetings and returns the data updated in the database.
     * @param {MeetingUpdateManyAndReturnArgs} args - Arguments to update many Meetings.
     * @example
     * // Update many Meetings
     * const meeting = await prisma.meeting.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Meetings and only return the `id`
     * const meetingWithIdOnly = await prisma.meeting.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MeetingUpdateManyAndReturnArgs>(args: SelectSubset<T, MeetingUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Meeting.
     * @param {MeetingUpsertArgs} args - Arguments to update or create a Meeting.
     * @example
     * // Update or create a Meeting
     * const meeting = await prisma.meeting.upsert({
     *   create: {
     *     // ... data to create a Meeting
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Meeting we want to update
     *   }
     * })
     */
    upsert<T extends MeetingUpsertArgs>(args: SelectSubset<T, MeetingUpsertArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Meetings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MeetingCountArgs} args - Arguments to filter Meetings to count.
     * @example
     * // Count the number of Meetings
     * const count = await prisma.meeting.count({
     *   where: {
     *     // ... the filter for the Meetings we want to count
     *   }
     * })
    **/
    count<T extends MeetingCountArgs>(
      args?: Subset<T, MeetingCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MeetingCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Meeting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MeetingAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MeetingAggregateArgs>(args: Subset<T, MeetingAggregateArgs>): Prisma.PrismaPromise<GetMeetingAggregateType<T>>

    /**
     * Group by Meeting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MeetingGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MeetingGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MeetingGroupByArgs['orderBy'] }
        : { orderBy?: MeetingGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MeetingGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMeetingGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Meeting model
   */
  readonly fields: MeetingFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Meeting.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MeetingClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    TranscriptChunk<T extends Meeting$TranscriptChunkArgs<ExtArgs> = {}>(args?: Subset<T, Meeting$TranscriptChunkArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Meeting model
   */
  interface MeetingFieldRefs {
    readonly id: FieldRef<"Meeting", 'String'>
    readonly userId: FieldRef<"Meeting", 'String'>
    readonly title: FieldRef<"Meeting", 'String'>
    readonly description: FieldRef<"Meeting", 'String'>
    readonly meetingUrl: FieldRef<"Meeting", 'String'>
    readonly startTime: FieldRef<"Meeting", 'DateTime'>
    readonly endTime: FieldRef<"Meeting", 'DateTime'>
    readonly attendees: FieldRef<"Meeting", 'Json'>
    readonly calendarEventId: FieldRef<"Meeting", 'String'>
    readonly isFromCalendar: FieldRef<"Meeting", 'Boolean'>
    readonly botScheduled: FieldRef<"Meeting", 'Boolean'>
    readonly botSent: FieldRef<"Meeting", 'Boolean'>
    readonly botId: FieldRef<"Meeting", 'String'>
    readonly botJoinedAt: FieldRef<"Meeting", 'DateTime'>
    readonly meetingEnded: FieldRef<"Meeting", 'Boolean'>
    readonly transcriptReady: FieldRef<"Meeting", 'Boolean'>
    readonly transcript: FieldRef<"Meeting", 'Json'>
    readonly recordingUrl: FieldRef<"Meeting", 'String'>
    readonly speakers: FieldRef<"Meeting", 'Json'>
    readonly summary: FieldRef<"Meeting", 'String'>
    readonly actionItems: FieldRef<"Meeting", 'Json'>
    readonly processed: FieldRef<"Meeting", 'Boolean'>
    readonly processedAt: FieldRef<"Meeting", 'DateTime'>
    readonly emailSent: FieldRef<"Meeting", 'Boolean'>
    readonly emailSentAt: FieldRef<"Meeting", 'DateTime'>
    readonly ragProcessed: FieldRef<"Meeting", 'Boolean'>
    readonly ragProcessedAt: FieldRef<"Meeting", 'DateTime'>
    readonly createdAt: FieldRef<"Meeting", 'DateTime'>
    readonly updatedAt: FieldRef<"Meeting", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Meeting findUnique
   */
  export type MeetingFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * Filter, which Meeting to fetch.
     */
    where: MeetingWhereUniqueInput
  }

  /**
   * Meeting findUniqueOrThrow
   */
  export type MeetingFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * Filter, which Meeting to fetch.
     */
    where: MeetingWhereUniqueInput
  }

  /**
   * Meeting findFirst
   */
  export type MeetingFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * Filter, which Meeting to fetch.
     */
    where?: MeetingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Meetings to fetch.
     */
    orderBy?: MeetingOrderByWithRelationInput | MeetingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Meetings.
     */
    cursor?: MeetingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Meetings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Meetings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Meetings.
     */
    distinct?: MeetingScalarFieldEnum | MeetingScalarFieldEnum[]
  }

  /**
   * Meeting findFirstOrThrow
   */
  export type MeetingFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * Filter, which Meeting to fetch.
     */
    where?: MeetingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Meetings to fetch.
     */
    orderBy?: MeetingOrderByWithRelationInput | MeetingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Meetings.
     */
    cursor?: MeetingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Meetings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Meetings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Meetings.
     */
    distinct?: MeetingScalarFieldEnum | MeetingScalarFieldEnum[]
  }

  /**
   * Meeting findMany
   */
  export type MeetingFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * Filter, which Meetings to fetch.
     */
    where?: MeetingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Meetings to fetch.
     */
    orderBy?: MeetingOrderByWithRelationInput | MeetingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Meetings.
     */
    cursor?: MeetingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Meetings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Meetings.
     */
    skip?: number
    distinct?: MeetingScalarFieldEnum | MeetingScalarFieldEnum[]
  }

  /**
   * Meeting create
   */
  export type MeetingCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * The data needed to create a Meeting.
     */
    data: XOR<MeetingCreateInput, MeetingUncheckedCreateInput>
  }

  /**
   * Meeting createMany
   */
  export type MeetingCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Meetings.
     */
    data: MeetingCreateManyInput | MeetingCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Meeting createManyAndReturn
   */
  export type MeetingCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * The data used to create many Meetings.
     */
    data: MeetingCreateManyInput | MeetingCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Meeting update
   */
  export type MeetingUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * The data needed to update a Meeting.
     */
    data: XOR<MeetingUpdateInput, MeetingUncheckedUpdateInput>
    /**
     * Choose, which Meeting to update.
     */
    where: MeetingWhereUniqueInput
  }

  /**
   * Meeting updateMany
   */
  export type MeetingUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Meetings.
     */
    data: XOR<MeetingUpdateManyMutationInput, MeetingUncheckedUpdateManyInput>
    /**
     * Filter which Meetings to update
     */
    where?: MeetingWhereInput
    /**
     * Limit how many Meetings to update.
     */
    limit?: number
  }

  /**
   * Meeting updateManyAndReturn
   */
  export type MeetingUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * The data used to update Meetings.
     */
    data: XOR<MeetingUpdateManyMutationInput, MeetingUncheckedUpdateManyInput>
    /**
     * Filter which Meetings to update
     */
    where?: MeetingWhereInput
    /**
     * Limit how many Meetings to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Meeting upsert
   */
  export type MeetingUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * The filter to search for the Meeting to update in case it exists.
     */
    where: MeetingWhereUniqueInput
    /**
     * In case the Meeting found by the `where` argument doesn't exist, create a new Meeting with this data.
     */
    create: XOR<MeetingCreateInput, MeetingUncheckedCreateInput>
    /**
     * In case the Meeting was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MeetingUpdateInput, MeetingUncheckedUpdateInput>
  }

  /**
   * Meeting delete
   */
  export type MeetingDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
    /**
     * Filter which Meeting to delete.
     */
    where: MeetingWhereUniqueInput
  }

  /**
   * Meeting deleteMany
   */
  export type MeetingDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Meetings to delete
     */
    where?: MeetingWhereInput
    /**
     * Limit how many Meetings to delete.
     */
    limit?: number
  }

  /**
   * Meeting.TranscriptChunk
   */
  export type Meeting$TranscriptChunkArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    where?: TranscriptChunkWhereInput
    orderBy?: TranscriptChunkOrderByWithRelationInput | TranscriptChunkOrderByWithRelationInput[]
    cursor?: TranscriptChunkWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TranscriptChunkScalarFieldEnum | TranscriptChunkScalarFieldEnum[]
  }

  /**
   * Meeting without action
   */
  export type MeetingDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Meeting
     */
    select?: MeetingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Meeting
     */
    omit?: MeetingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MeetingInclude<ExtArgs> | null
  }


  /**
   * Model UserIntegration
   */

  export type AggregateUserIntegration = {
    _count: UserIntegrationCountAggregateOutputType | null
    _min: UserIntegrationMinAggregateOutputType | null
    _max: UserIntegrationMaxAggregateOutputType | null
  }

  export type UserIntegrationMinAggregateOutputType = {
    id: string | null
    userId: string | null
    platform: string | null
    accessToken: string | null
    refreshToken: string | null
    expiresAt: Date | null
    boardId: string | null
    boardName: string | null
    projectId: string | null
    projectName: string | null
    workspaceId: string | null
    domain: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserIntegrationMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    platform: string | null
    accessToken: string | null
    refreshToken: string | null
    expiresAt: Date | null
    boardId: string | null
    boardName: string | null
    projectId: string | null
    projectName: string | null
    workspaceId: string | null
    domain: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserIntegrationCountAggregateOutputType = {
    id: number
    userId: number
    platform: number
    accessToken: number
    refreshToken: number
    expiresAt: number
    boardId: number
    boardName: number
    projectId: number
    projectName: number
    workspaceId: number
    domain: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserIntegrationMinAggregateInputType = {
    id?: true
    userId?: true
    platform?: true
    accessToken?: true
    refreshToken?: true
    expiresAt?: true
    boardId?: true
    boardName?: true
    projectId?: true
    projectName?: true
    workspaceId?: true
    domain?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserIntegrationMaxAggregateInputType = {
    id?: true
    userId?: true
    platform?: true
    accessToken?: true
    refreshToken?: true
    expiresAt?: true
    boardId?: true
    boardName?: true
    projectId?: true
    projectName?: true
    workspaceId?: true
    domain?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserIntegrationCountAggregateInputType = {
    id?: true
    userId?: true
    platform?: true
    accessToken?: true
    refreshToken?: true
    expiresAt?: true
    boardId?: true
    boardName?: true
    projectId?: true
    projectName?: true
    workspaceId?: true
    domain?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserIntegrationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserIntegration to aggregate.
     */
    where?: UserIntegrationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserIntegrations to fetch.
     */
    orderBy?: UserIntegrationOrderByWithRelationInput | UserIntegrationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserIntegrationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserIntegrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserIntegrations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned UserIntegrations
    **/
    _count?: true | UserIntegrationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserIntegrationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserIntegrationMaxAggregateInputType
  }

  export type GetUserIntegrationAggregateType<T extends UserIntegrationAggregateArgs> = {
        [P in keyof T & keyof AggregateUserIntegration]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUserIntegration[P]>
      : GetScalarType<T[P], AggregateUserIntegration[P]>
  }




  export type UserIntegrationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserIntegrationWhereInput
    orderBy?: UserIntegrationOrderByWithAggregationInput | UserIntegrationOrderByWithAggregationInput[]
    by: UserIntegrationScalarFieldEnum[] | UserIntegrationScalarFieldEnum
    having?: UserIntegrationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserIntegrationCountAggregateInputType | true
    _min?: UserIntegrationMinAggregateInputType
    _max?: UserIntegrationMaxAggregateInputType
  }

  export type UserIntegrationGroupByOutputType = {
    id: string
    userId: string
    platform: string
    accessToken: string
    refreshToken: string | null
    expiresAt: Date | null
    boardId: string | null
    boardName: string | null
    projectId: string | null
    projectName: string | null
    workspaceId: string | null
    domain: string | null
    createdAt: Date
    updatedAt: Date
    _count: UserIntegrationCountAggregateOutputType | null
    _min: UserIntegrationMinAggregateOutputType | null
    _max: UserIntegrationMaxAggregateOutputType | null
  }

  type GetUserIntegrationGroupByPayload<T extends UserIntegrationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserIntegrationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserIntegrationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserIntegrationGroupByOutputType[P]>
            : GetScalarType<T[P], UserIntegrationGroupByOutputType[P]>
        }
      >
    >


  export type UserIntegrationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    platform?: boolean
    accessToken?: boolean
    refreshToken?: boolean
    expiresAt?: boolean
    boardId?: boolean
    boardName?: boolean
    projectId?: boolean
    projectName?: boolean
    workspaceId?: boolean
    domain?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["userIntegration"]>

  export type UserIntegrationSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    platform?: boolean
    accessToken?: boolean
    refreshToken?: boolean
    expiresAt?: boolean
    boardId?: boolean
    boardName?: boolean
    projectId?: boolean
    projectName?: boolean
    workspaceId?: boolean
    domain?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["userIntegration"]>

  export type UserIntegrationSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    platform?: boolean
    accessToken?: boolean
    refreshToken?: boolean
    expiresAt?: boolean
    boardId?: boolean
    boardName?: boolean
    projectId?: boolean
    projectName?: boolean
    workspaceId?: boolean
    domain?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["userIntegration"]>

  export type UserIntegrationSelectScalar = {
    id?: boolean
    userId?: boolean
    platform?: boolean
    accessToken?: boolean
    refreshToken?: boolean
    expiresAt?: boolean
    boardId?: boolean
    boardName?: boolean
    projectId?: boolean
    projectName?: boolean
    workspaceId?: boolean
    domain?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserIntegrationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "platform" | "accessToken" | "refreshToken" | "expiresAt" | "boardId" | "boardName" | "projectId" | "projectName" | "workspaceId" | "domain" | "createdAt" | "updatedAt", ExtArgs["result"]["userIntegration"]>

  export type $UserIntegrationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "UserIntegration"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      platform: string
      accessToken: string
      refreshToken: string | null
      expiresAt: Date | null
      boardId: string | null
      boardName: string | null
      projectId: string | null
      projectName: string | null
      workspaceId: string | null
      domain: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["userIntegration"]>
    composites: {}
  }

  type UserIntegrationGetPayload<S extends boolean | null | undefined | UserIntegrationDefaultArgs> = $Result.GetResult<Prisma.$UserIntegrationPayload, S>

  type UserIntegrationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserIntegrationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserIntegrationCountAggregateInputType | true
    }

  export interface UserIntegrationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['UserIntegration'], meta: { name: 'UserIntegration' } }
    /**
     * Find zero or one UserIntegration that matches the filter.
     * @param {UserIntegrationFindUniqueArgs} args - Arguments to find a UserIntegration
     * @example
     * // Get one UserIntegration
     * const userIntegration = await prisma.userIntegration.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserIntegrationFindUniqueArgs>(args: SelectSubset<T, UserIntegrationFindUniqueArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one UserIntegration that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserIntegrationFindUniqueOrThrowArgs} args - Arguments to find a UserIntegration
     * @example
     * // Get one UserIntegration
     * const userIntegration = await prisma.userIntegration.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserIntegrationFindUniqueOrThrowArgs>(args: SelectSubset<T, UserIntegrationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserIntegration that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserIntegrationFindFirstArgs} args - Arguments to find a UserIntegration
     * @example
     * // Get one UserIntegration
     * const userIntegration = await prisma.userIntegration.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserIntegrationFindFirstArgs>(args?: SelectSubset<T, UserIntegrationFindFirstArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserIntegration that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserIntegrationFindFirstOrThrowArgs} args - Arguments to find a UserIntegration
     * @example
     * // Get one UserIntegration
     * const userIntegration = await prisma.userIntegration.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserIntegrationFindFirstOrThrowArgs>(args?: SelectSubset<T, UserIntegrationFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more UserIntegrations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserIntegrationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UserIntegrations
     * const userIntegrations = await prisma.userIntegration.findMany()
     * 
     * // Get first 10 UserIntegrations
     * const userIntegrations = await prisma.userIntegration.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userIntegrationWithIdOnly = await prisma.userIntegration.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserIntegrationFindManyArgs>(args?: SelectSubset<T, UserIntegrationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a UserIntegration.
     * @param {UserIntegrationCreateArgs} args - Arguments to create a UserIntegration.
     * @example
     * // Create one UserIntegration
     * const UserIntegration = await prisma.userIntegration.create({
     *   data: {
     *     // ... data to create a UserIntegration
     *   }
     * })
     * 
     */
    create<T extends UserIntegrationCreateArgs>(args: SelectSubset<T, UserIntegrationCreateArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many UserIntegrations.
     * @param {UserIntegrationCreateManyArgs} args - Arguments to create many UserIntegrations.
     * @example
     * // Create many UserIntegrations
     * const userIntegration = await prisma.userIntegration.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserIntegrationCreateManyArgs>(args?: SelectSubset<T, UserIntegrationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many UserIntegrations and returns the data saved in the database.
     * @param {UserIntegrationCreateManyAndReturnArgs} args - Arguments to create many UserIntegrations.
     * @example
     * // Create many UserIntegrations
     * const userIntegration = await prisma.userIntegration.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many UserIntegrations and only return the `id`
     * const userIntegrationWithIdOnly = await prisma.userIntegration.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserIntegrationCreateManyAndReturnArgs>(args?: SelectSubset<T, UserIntegrationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a UserIntegration.
     * @param {UserIntegrationDeleteArgs} args - Arguments to delete one UserIntegration.
     * @example
     * // Delete one UserIntegration
     * const UserIntegration = await prisma.userIntegration.delete({
     *   where: {
     *     // ... filter to delete one UserIntegration
     *   }
     * })
     * 
     */
    delete<T extends UserIntegrationDeleteArgs>(args: SelectSubset<T, UserIntegrationDeleteArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one UserIntegration.
     * @param {UserIntegrationUpdateArgs} args - Arguments to update one UserIntegration.
     * @example
     * // Update one UserIntegration
     * const userIntegration = await prisma.userIntegration.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserIntegrationUpdateArgs>(args: SelectSubset<T, UserIntegrationUpdateArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more UserIntegrations.
     * @param {UserIntegrationDeleteManyArgs} args - Arguments to filter UserIntegrations to delete.
     * @example
     * // Delete a few UserIntegrations
     * const { count } = await prisma.userIntegration.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserIntegrationDeleteManyArgs>(args?: SelectSubset<T, UserIntegrationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserIntegrations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserIntegrationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UserIntegrations
     * const userIntegration = await prisma.userIntegration.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserIntegrationUpdateManyArgs>(args: SelectSubset<T, UserIntegrationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserIntegrations and returns the data updated in the database.
     * @param {UserIntegrationUpdateManyAndReturnArgs} args - Arguments to update many UserIntegrations.
     * @example
     * // Update many UserIntegrations
     * const userIntegration = await prisma.userIntegration.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more UserIntegrations and only return the `id`
     * const userIntegrationWithIdOnly = await prisma.userIntegration.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserIntegrationUpdateManyAndReturnArgs>(args: SelectSubset<T, UserIntegrationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one UserIntegration.
     * @param {UserIntegrationUpsertArgs} args - Arguments to update or create a UserIntegration.
     * @example
     * // Update or create a UserIntegration
     * const userIntegration = await prisma.userIntegration.upsert({
     *   create: {
     *     // ... data to create a UserIntegration
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UserIntegration we want to update
     *   }
     * })
     */
    upsert<T extends UserIntegrationUpsertArgs>(args: SelectSubset<T, UserIntegrationUpsertArgs<ExtArgs>>): Prisma__UserIntegrationClient<$Result.GetResult<Prisma.$UserIntegrationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of UserIntegrations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserIntegrationCountArgs} args - Arguments to filter UserIntegrations to count.
     * @example
     * // Count the number of UserIntegrations
     * const count = await prisma.userIntegration.count({
     *   where: {
     *     // ... the filter for the UserIntegrations we want to count
     *   }
     * })
    **/
    count<T extends UserIntegrationCountArgs>(
      args?: Subset<T, UserIntegrationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserIntegrationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UserIntegration.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserIntegrationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserIntegrationAggregateArgs>(args: Subset<T, UserIntegrationAggregateArgs>): Prisma.PrismaPromise<GetUserIntegrationAggregateType<T>>

    /**
     * Group by UserIntegration.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserIntegrationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserIntegrationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserIntegrationGroupByArgs['orderBy'] }
        : { orderBy?: UserIntegrationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserIntegrationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserIntegrationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the UserIntegration model
   */
  readonly fields: UserIntegrationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for UserIntegration.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserIntegrationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the UserIntegration model
   */
  interface UserIntegrationFieldRefs {
    readonly id: FieldRef<"UserIntegration", 'String'>
    readonly userId: FieldRef<"UserIntegration", 'String'>
    readonly platform: FieldRef<"UserIntegration", 'String'>
    readonly accessToken: FieldRef<"UserIntegration", 'String'>
    readonly refreshToken: FieldRef<"UserIntegration", 'String'>
    readonly expiresAt: FieldRef<"UserIntegration", 'DateTime'>
    readonly boardId: FieldRef<"UserIntegration", 'String'>
    readonly boardName: FieldRef<"UserIntegration", 'String'>
    readonly projectId: FieldRef<"UserIntegration", 'String'>
    readonly projectName: FieldRef<"UserIntegration", 'String'>
    readonly workspaceId: FieldRef<"UserIntegration", 'String'>
    readonly domain: FieldRef<"UserIntegration", 'String'>
    readonly createdAt: FieldRef<"UserIntegration", 'DateTime'>
    readonly updatedAt: FieldRef<"UserIntegration", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * UserIntegration findUnique
   */
  export type UserIntegrationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * Filter, which UserIntegration to fetch.
     */
    where: UserIntegrationWhereUniqueInput
  }

  /**
   * UserIntegration findUniqueOrThrow
   */
  export type UserIntegrationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * Filter, which UserIntegration to fetch.
     */
    where: UserIntegrationWhereUniqueInput
  }

  /**
   * UserIntegration findFirst
   */
  export type UserIntegrationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * Filter, which UserIntegration to fetch.
     */
    where?: UserIntegrationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserIntegrations to fetch.
     */
    orderBy?: UserIntegrationOrderByWithRelationInput | UserIntegrationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserIntegrations.
     */
    cursor?: UserIntegrationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserIntegrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserIntegrations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserIntegrations.
     */
    distinct?: UserIntegrationScalarFieldEnum | UserIntegrationScalarFieldEnum[]
  }

  /**
   * UserIntegration findFirstOrThrow
   */
  export type UserIntegrationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * Filter, which UserIntegration to fetch.
     */
    where?: UserIntegrationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserIntegrations to fetch.
     */
    orderBy?: UserIntegrationOrderByWithRelationInput | UserIntegrationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserIntegrations.
     */
    cursor?: UserIntegrationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserIntegrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserIntegrations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserIntegrations.
     */
    distinct?: UserIntegrationScalarFieldEnum | UserIntegrationScalarFieldEnum[]
  }

  /**
   * UserIntegration findMany
   */
  export type UserIntegrationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * Filter, which UserIntegrations to fetch.
     */
    where?: UserIntegrationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserIntegrations to fetch.
     */
    orderBy?: UserIntegrationOrderByWithRelationInput | UserIntegrationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing UserIntegrations.
     */
    cursor?: UserIntegrationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserIntegrations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserIntegrations.
     */
    skip?: number
    distinct?: UserIntegrationScalarFieldEnum | UserIntegrationScalarFieldEnum[]
  }

  /**
   * UserIntegration create
   */
  export type UserIntegrationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * The data needed to create a UserIntegration.
     */
    data: XOR<UserIntegrationCreateInput, UserIntegrationUncheckedCreateInput>
  }

  /**
   * UserIntegration createMany
   */
  export type UserIntegrationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many UserIntegrations.
     */
    data: UserIntegrationCreateManyInput | UserIntegrationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * UserIntegration createManyAndReturn
   */
  export type UserIntegrationCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * The data used to create many UserIntegrations.
     */
    data: UserIntegrationCreateManyInput | UserIntegrationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * UserIntegration update
   */
  export type UserIntegrationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * The data needed to update a UserIntegration.
     */
    data: XOR<UserIntegrationUpdateInput, UserIntegrationUncheckedUpdateInput>
    /**
     * Choose, which UserIntegration to update.
     */
    where: UserIntegrationWhereUniqueInput
  }

  /**
   * UserIntegration updateMany
   */
  export type UserIntegrationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update UserIntegrations.
     */
    data: XOR<UserIntegrationUpdateManyMutationInput, UserIntegrationUncheckedUpdateManyInput>
    /**
     * Filter which UserIntegrations to update
     */
    where?: UserIntegrationWhereInput
    /**
     * Limit how many UserIntegrations to update.
     */
    limit?: number
  }

  /**
   * UserIntegration updateManyAndReturn
   */
  export type UserIntegrationUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * The data used to update UserIntegrations.
     */
    data: XOR<UserIntegrationUpdateManyMutationInput, UserIntegrationUncheckedUpdateManyInput>
    /**
     * Filter which UserIntegrations to update
     */
    where?: UserIntegrationWhereInput
    /**
     * Limit how many UserIntegrations to update.
     */
    limit?: number
  }

  /**
   * UserIntegration upsert
   */
  export type UserIntegrationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * The filter to search for the UserIntegration to update in case it exists.
     */
    where: UserIntegrationWhereUniqueInput
    /**
     * In case the UserIntegration found by the `where` argument doesn't exist, create a new UserIntegration with this data.
     */
    create: XOR<UserIntegrationCreateInput, UserIntegrationUncheckedCreateInput>
    /**
     * In case the UserIntegration was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserIntegrationUpdateInput, UserIntegrationUncheckedUpdateInput>
  }

  /**
   * UserIntegration delete
   */
  export type UserIntegrationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
    /**
     * Filter which UserIntegration to delete.
     */
    where: UserIntegrationWhereUniqueInput
  }

  /**
   * UserIntegration deleteMany
   */
  export type UserIntegrationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserIntegrations to delete
     */
    where?: UserIntegrationWhereInput
    /**
     * Limit how many UserIntegrations to delete.
     */
    limit?: number
  }

  /**
   * UserIntegration without action
   */
  export type UserIntegrationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserIntegration
     */
    select?: UserIntegrationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserIntegration
     */
    omit?: UserIntegrationOmit<ExtArgs> | null
  }


  /**
   * Model TranscriptChunk
   */

  export type AggregateTranscriptChunk = {
    _count: TranscriptChunkCountAggregateOutputType | null
    _avg: TranscriptChunkAvgAggregateOutputType | null
    _sum: TranscriptChunkSumAggregateOutputType | null
    _min: TranscriptChunkMinAggregateOutputType | null
    _max: TranscriptChunkMaxAggregateOutputType | null
  }

  export type TranscriptChunkAvgAggregateOutputType = {
    chunkIndex: number | null
  }

  export type TranscriptChunkSumAggregateOutputType = {
    chunkIndex: number | null
  }

  export type TranscriptChunkMinAggregateOutputType = {
    id: string | null
    meetingId: string | null
    chunkIndex: number | null
    content: string | null
    speakerName: string | null
    vectorId: string | null
    createdAt: Date | null
  }

  export type TranscriptChunkMaxAggregateOutputType = {
    id: string | null
    meetingId: string | null
    chunkIndex: number | null
    content: string | null
    speakerName: string | null
    vectorId: string | null
    createdAt: Date | null
  }

  export type TranscriptChunkCountAggregateOutputType = {
    id: number
    meetingId: number
    chunkIndex: number
    content: number
    speakerName: number
    vectorId: number
    createdAt: number
    _all: number
  }


  export type TranscriptChunkAvgAggregateInputType = {
    chunkIndex?: true
  }

  export type TranscriptChunkSumAggregateInputType = {
    chunkIndex?: true
  }

  export type TranscriptChunkMinAggregateInputType = {
    id?: true
    meetingId?: true
    chunkIndex?: true
    content?: true
    speakerName?: true
    vectorId?: true
    createdAt?: true
  }

  export type TranscriptChunkMaxAggregateInputType = {
    id?: true
    meetingId?: true
    chunkIndex?: true
    content?: true
    speakerName?: true
    vectorId?: true
    createdAt?: true
  }

  export type TranscriptChunkCountAggregateInputType = {
    id?: true
    meetingId?: true
    chunkIndex?: true
    content?: true
    speakerName?: true
    vectorId?: true
    createdAt?: true
    _all?: true
  }

  export type TranscriptChunkAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TranscriptChunk to aggregate.
     */
    where?: TranscriptChunkWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TranscriptChunks to fetch.
     */
    orderBy?: TranscriptChunkOrderByWithRelationInput | TranscriptChunkOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TranscriptChunkWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TranscriptChunks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TranscriptChunks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TranscriptChunks
    **/
    _count?: true | TranscriptChunkCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TranscriptChunkAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TranscriptChunkSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TranscriptChunkMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TranscriptChunkMaxAggregateInputType
  }

  export type GetTranscriptChunkAggregateType<T extends TranscriptChunkAggregateArgs> = {
        [P in keyof T & keyof AggregateTranscriptChunk]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTranscriptChunk[P]>
      : GetScalarType<T[P], AggregateTranscriptChunk[P]>
  }




  export type TranscriptChunkGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TranscriptChunkWhereInput
    orderBy?: TranscriptChunkOrderByWithAggregationInput | TranscriptChunkOrderByWithAggregationInput[]
    by: TranscriptChunkScalarFieldEnum[] | TranscriptChunkScalarFieldEnum
    having?: TranscriptChunkScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TranscriptChunkCountAggregateInputType | true
    _avg?: TranscriptChunkAvgAggregateInputType
    _sum?: TranscriptChunkSumAggregateInputType
    _min?: TranscriptChunkMinAggregateInputType
    _max?: TranscriptChunkMaxAggregateInputType
  }

  export type TranscriptChunkGroupByOutputType = {
    id: string
    meetingId: string
    chunkIndex: number
    content: string
    speakerName: string | null
    vectorId: string | null
    createdAt: Date
    _count: TranscriptChunkCountAggregateOutputType | null
    _avg: TranscriptChunkAvgAggregateOutputType | null
    _sum: TranscriptChunkSumAggregateOutputType | null
    _min: TranscriptChunkMinAggregateOutputType | null
    _max: TranscriptChunkMaxAggregateOutputType | null
  }

  type GetTranscriptChunkGroupByPayload<T extends TranscriptChunkGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TranscriptChunkGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TranscriptChunkGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TranscriptChunkGroupByOutputType[P]>
            : GetScalarType<T[P], TranscriptChunkGroupByOutputType[P]>
        }
      >
    >


  export type TranscriptChunkSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    meetingId?: boolean
    chunkIndex?: boolean
    content?: boolean
    speakerName?: boolean
    vectorId?: boolean
    createdAt?: boolean
    meeting?: boolean | MeetingDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["transcriptChunk"]>

  export type TranscriptChunkSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    meetingId?: boolean
    chunkIndex?: boolean
    content?: boolean
    speakerName?: boolean
    vectorId?: boolean
    createdAt?: boolean
    meeting?: boolean | MeetingDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["transcriptChunk"]>

  export type TranscriptChunkSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    meetingId?: boolean
    chunkIndex?: boolean
    content?: boolean
    speakerName?: boolean
    vectorId?: boolean
    createdAt?: boolean
    meeting?: boolean | MeetingDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["transcriptChunk"]>

  export type TranscriptChunkSelectScalar = {
    id?: boolean
    meetingId?: boolean
    chunkIndex?: boolean
    content?: boolean
    speakerName?: boolean
    vectorId?: boolean
    createdAt?: boolean
  }

  export type TranscriptChunkOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "meetingId" | "chunkIndex" | "content" | "speakerName" | "vectorId" | "createdAt", ExtArgs["result"]["transcriptChunk"]>
  export type TranscriptChunkInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    meeting?: boolean | MeetingDefaultArgs<ExtArgs>
  }
  export type TranscriptChunkIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    meeting?: boolean | MeetingDefaultArgs<ExtArgs>
  }
  export type TranscriptChunkIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    meeting?: boolean | MeetingDefaultArgs<ExtArgs>
  }

  export type $TranscriptChunkPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TranscriptChunk"
    objects: {
      meeting: Prisma.$MeetingPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      meetingId: string
      chunkIndex: number
      content: string
      speakerName: string | null
      vectorId: string | null
      createdAt: Date
    }, ExtArgs["result"]["transcriptChunk"]>
    composites: {}
  }

  type TranscriptChunkGetPayload<S extends boolean | null | undefined | TranscriptChunkDefaultArgs> = $Result.GetResult<Prisma.$TranscriptChunkPayload, S>

  type TranscriptChunkCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TranscriptChunkFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TranscriptChunkCountAggregateInputType | true
    }

  export interface TranscriptChunkDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TranscriptChunk'], meta: { name: 'TranscriptChunk' } }
    /**
     * Find zero or one TranscriptChunk that matches the filter.
     * @param {TranscriptChunkFindUniqueArgs} args - Arguments to find a TranscriptChunk
     * @example
     * // Get one TranscriptChunk
     * const transcriptChunk = await prisma.transcriptChunk.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TranscriptChunkFindUniqueArgs>(args: SelectSubset<T, TranscriptChunkFindUniqueArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one TranscriptChunk that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TranscriptChunkFindUniqueOrThrowArgs} args - Arguments to find a TranscriptChunk
     * @example
     * // Get one TranscriptChunk
     * const transcriptChunk = await prisma.transcriptChunk.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TranscriptChunkFindUniqueOrThrowArgs>(args: SelectSubset<T, TranscriptChunkFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TranscriptChunk that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TranscriptChunkFindFirstArgs} args - Arguments to find a TranscriptChunk
     * @example
     * // Get one TranscriptChunk
     * const transcriptChunk = await prisma.transcriptChunk.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TranscriptChunkFindFirstArgs>(args?: SelectSubset<T, TranscriptChunkFindFirstArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TranscriptChunk that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TranscriptChunkFindFirstOrThrowArgs} args - Arguments to find a TranscriptChunk
     * @example
     * // Get one TranscriptChunk
     * const transcriptChunk = await prisma.transcriptChunk.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TranscriptChunkFindFirstOrThrowArgs>(args?: SelectSubset<T, TranscriptChunkFindFirstOrThrowArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more TranscriptChunks that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TranscriptChunkFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TranscriptChunks
     * const transcriptChunks = await prisma.transcriptChunk.findMany()
     * 
     * // Get first 10 TranscriptChunks
     * const transcriptChunks = await prisma.transcriptChunk.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const transcriptChunkWithIdOnly = await prisma.transcriptChunk.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TranscriptChunkFindManyArgs>(args?: SelectSubset<T, TranscriptChunkFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a TranscriptChunk.
     * @param {TranscriptChunkCreateArgs} args - Arguments to create a TranscriptChunk.
     * @example
     * // Create one TranscriptChunk
     * const TranscriptChunk = await prisma.transcriptChunk.create({
     *   data: {
     *     // ... data to create a TranscriptChunk
     *   }
     * })
     * 
     */
    create<T extends TranscriptChunkCreateArgs>(args: SelectSubset<T, TranscriptChunkCreateArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many TranscriptChunks.
     * @param {TranscriptChunkCreateManyArgs} args - Arguments to create many TranscriptChunks.
     * @example
     * // Create many TranscriptChunks
     * const transcriptChunk = await prisma.transcriptChunk.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TranscriptChunkCreateManyArgs>(args?: SelectSubset<T, TranscriptChunkCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many TranscriptChunks and returns the data saved in the database.
     * @param {TranscriptChunkCreateManyAndReturnArgs} args - Arguments to create many TranscriptChunks.
     * @example
     * // Create many TranscriptChunks
     * const transcriptChunk = await prisma.transcriptChunk.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many TranscriptChunks and only return the `id`
     * const transcriptChunkWithIdOnly = await prisma.transcriptChunk.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends TranscriptChunkCreateManyAndReturnArgs>(args?: SelectSubset<T, TranscriptChunkCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a TranscriptChunk.
     * @param {TranscriptChunkDeleteArgs} args - Arguments to delete one TranscriptChunk.
     * @example
     * // Delete one TranscriptChunk
     * const TranscriptChunk = await prisma.transcriptChunk.delete({
     *   where: {
     *     // ... filter to delete one TranscriptChunk
     *   }
     * })
     * 
     */
    delete<T extends TranscriptChunkDeleteArgs>(args: SelectSubset<T, TranscriptChunkDeleteArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one TranscriptChunk.
     * @param {TranscriptChunkUpdateArgs} args - Arguments to update one TranscriptChunk.
     * @example
     * // Update one TranscriptChunk
     * const transcriptChunk = await prisma.transcriptChunk.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TranscriptChunkUpdateArgs>(args: SelectSubset<T, TranscriptChunkUpdateArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more TranscriptChunks.
     * @param {TranscriptChunkDeleteManyArgs} args - Arguments to filter TranscriptChunks to delete.
     * @example
     * // Delete a few TranscriptChunks
     * const { count } = await prisma.transcriptChunk.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TranscriptChunkDeleteManyArgs>(args?: SelectSubset<T, TranscriptChunkDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TranscriptChunks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TranscriptChunkUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TranscriptChunks
     * const transcriptChunk = await prisma.transcriptChunk.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TranscriptChunkUpdateManyArgs>(args: SelectSubset<T, TranscriptChunkUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TranscriptChunks and returns the data updated in the database.
     * @param {TranscriptChunkUpdateManyAndReturnArgs} args - Arguments to update many TranscriptChunks.
     * @example
     * // Update many TranscriptChunks
     * const transcriptChunk = await prisma.transcriptChunk.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more TranscriptChunks and only return the `id`
     * const transcriptChunkWithIdOnly = await prisma.transcriptChunk.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends TranscriptChunkUpdateManyAndReturnArgs>(args: SelectSubset<T, TranscriptChunkUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one TranscriptChunk.
     * @param {TranscriptChunkUpsertArgs} args - Arguments to update or create a TranscriptChunk.
     * @example
     * // Update or create a TranscriptChunk
     * const transcriptChunk = await prisma.transcriptChunk.upsert({
     *   create: {
     *     // ... data to create a TranscriptChunk
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TranscriptChunk we want to update
     *   }
     * })
     */
    upsert<T extends TranscriptChunkUpsertArgs>(args: SelectSubset<T, TranscriptChunkUpsertArgs<ExtArgs>>): Prisma__TranscriptChunkClient<$Result.GetResult<Prisma.$TranscriptChunkPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of TranscriptChunks.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TranscriptChunkCountArgs} args - Arguments to filter TranscriptChunks to count.
     * @example
     * // Count the number of TranscriptChunks
     * const count = await prisma.transcriptChunk.count({
     *   where: {
     *     // ... the filter for the TranscriptChunks we want to count
     *   }
     * })
    **/
    count<T extends TranscriptChunkCountArgs>(
      args?: Subset<T, TranscriptChunkCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TranscriptChunkCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TranscriptChunk.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TranscriptChunkAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TranscriptChunkAggregateArgs>(args: Subset<T, TranscriptChunkAggregateArgs>): Prisma.PrismaPromise<GetTranscriptChunkAggregateType<T>>

    /**
     * Group by TranscriptChunk.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TranscriptChunkGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TranscriptChunkGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TranscriptChunkGroupByArgs['orderBy'] }
        : { orderBy?: TranscriptChunkGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TranscriptChunkGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTranscriptChunkGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TranscriptChunk model
   */
  readonly fields: TranscriptChunkFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TranscriptChunk.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TranscriptChunkClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    meeting<T extends MeetingDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MeetingDefaultArgs<ExtArgs>>): Prisma__MeetingClient<$Result.GetResult<Prisma.$MeetingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TranscriptChunk model
   */
  interface TranscriptChunkFieldRefs {
    readonly id: FieldRef<"TranscriptChunk", 'String'>
    readonly meetingId: FieldRef<"TranscriptChunk", 'String'>
    readonly chunkIndex: FieldRef<"TranscriptChunk", 'Int'>
    readonly content: FieldRef<"TranscriptChunk", 'String'>
    readonly speakerName: FieldRef<"TranscriptChunk", 'String'>
    readonly vectorId: FieldRef<"TranscriptChunk", 'String'>
    readonly createdAt: FieldRef<"TranscriptChunk", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * TranscriptChunk findUnique
   */
  export type TranscriptChunkFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * Filter, which TranscriptChunk to fetch.
     */
    where: TranscriptChunkWhereUniqueInput
  }

  /**
   * TranscriptChunk findUniqueOrThrow
   */
  export type TranscriptChunkFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * Filter, which TranscriptChunk to fetch.
     */
    where: TranscriptChunkWhereUniqueInput
  }

  /**
   * TranscriptChunk findFirst
   */
  export type TranscriptChunkFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * Filter, which TranscriptChunk to fetch.
     */
    where?: TranscriptChunkWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TranscriptChunks to fetch.
     */
    orderBy?: TranscriptChunkOrderByWithRelationInput | TranscriptChunkOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TranscriptChunks.
     */
    cursor?: TranscriptChunkWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TranscriptChunks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TranscriptChunks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TranscriptChunks.
     */
    distinct?: TranscriptChunkScalarFieldEnum | TranscriptChunkScalarFieldEnum[]
  }

  /**
   * TranscriptChunk findFirstOrThrow
   */
  export type TranscriptChunkFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * Filter, which TranscriptChunk to fetch.
     */
    where?: TranscriptChunkWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TranscriptChunks to fetch.
     */
    orderBy?: TranscriptChunkOrderByWithRelationInput | TranscriptChunkOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TranscriptChunks.
     */
    cursor?: TranscriptChunkWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TranscriptChunks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TranscriptChunks.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TranscriptChunks.
     */
    distinct?: TranscriptChunkScalarFieldEnum | TranscriptChunkScalarFieldEnum[]
  }

  /**
   * TranscriptChunk findMany
   */
  export type TranscriptChunkFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * Filter, which TranscriptChunks to fetch.
     */
    where?: TranscriptChunkWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TranscriptChunks to fetch.
     */
    orderBy?: TranscriptChunkOrderByWithRelationInput | TranscriptChunkOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TranscriptChunks.
     */
    cursor?: TranscriptChunkWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TranscriptChunks from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TranscriptChunks.
     */
    skip?: number
    distinct?: TranscriptChunkScalarFieldEnum | TranscriptChunkScalarFieldEnum[]
  }

  /**
   * TranscriptChunk create
   */
  export type TranscriptChunkCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * The data needed to create a TranscriptChunk.
     */
    data: XOR<TranscriptChunkCreateInput, TranscriptChunkUncheckedCreateInput>
  }

  /**
   * TranscriptChunk createMany
   */
  export type TranscriptChunkCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TranscriptChunks.
     */
    data: TranscriptChunkCreateManyInput | TranscriptChunkCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TranscriptChunk createManyAndReturn
   */
  export type TranscriptChunkCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * The data used to create many TranscriptChunks.
     */
    data: TranscriptChunkCreateManyInput | TranscriptChunkCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * TranscriptChunk update
   */
  export type TranscriptChunkUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * The data needed to update a TranscriptChunk.
     */
    data: XOR<TranscriptChunkUpdateInput, TranscriptChunkUncheckedUpdateInput>
    /**
     * Choose, which TranscriptChunk to update.
     */
    where: TranscriptChunkWhereUniqueInput
  }

  /**
   * TranscriptChunk updateMany
   */
  export type TranscriptChunkUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TranscriptChunks.
     */
    data: XOR<TranscriptChunkUpdateManyMutationInput, TranscriptChunkUncheckedUpdateManyInput>
    /**
     * Filter which TranscriptChunks to update
     */
    where?: TranscriptChunkWhereInput
    /**
     * Limit how many TranscriptChunks to update.
     */
    limit?: number
  }

  /**
   * TranscriptChunk updateManyAndReturn
   */
  export type TranscriptChunkUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * The data used to update TranscriptChunks.
     */
    data: XOR<TranscriptChunkUpdateManyMutationInput, TranscriptChunkUncheckedUpdateManyInput>
    /**
     * Filter which TranscriptChunks to update
     */
    where?: TranscriptChunkWhereInput
    /**
     * Limit how many TranscriptChunks to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * TranscriptChunk upsert
   */
  export type TranscriptChunkUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * The filter to search for the TranscriptChunk to update in case it exists.
     */
    where: TranscriptChunkWhereUniqueInput
    /**
     * In case the TranscriptChunk found by the `where` argument doesn't exist, create a new TranscriptChunk with this data.
     */
    create: XOR<TranscriptChunkCreateInput, TranscriptChunkUncheckedCreateInput>
    /**
     * In case the TranscriptChunk was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TranscriptChunkUpdateInput, TranscriptChunkUncheckedUpdateInput>
  }

  /**
   * TranscriptChunk delete
   */
  export type TranscriptChunkDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
    /**
     * Filter which TranscriptChunk to delete.
     */
    where: TranscriptChunkWhereUniqueInput
  }

  /**
   * TranscriptChunk deleteMany
   */
  export type TranscriptChunkDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TranscriptChunks to delete
     */
    where?: TranscriptChunkWhereInput
    /**
     * Limit how many TranscriptChunks to delete.
     */
    limit?: number
  }

  /**
   * TranscriptChunk without action
   */
  export type TranscriptChunkDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TranscriptChunk
     */
    select?: TranscriptChunkSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TranscriptChunk
     */
    omit?: TranscriptChunkOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TranscriptChunkInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    clerkId: 'clerkId',
    email: 'email',
    name: 'name',
    botName: 'botName',
    botImageUrl: 'botImageUrl',
    googleAccessToken: 'googleAccessToken',
    googleRefreshToken: 'googleRefreshToken',
    googleTokenExpiry: 'googleTokenExpiry',
    calendarConnected: 'calendarConnected',
    slackUserId: 'slackUserId',
    slackTeamId: 'slackTeamId',
    slackConnected: 'slackConnected',
    preferredChannelId: 'preferredChannelId',
    preferredChannelName: 'preferredChannelName',
    currentPlan: 'currentPlan',
    subscriptionStatus: 'subscriptionStatus',
    stripeCustomerId: 'stripeCustomerId',
    stripeSubscriptionId: 'stripeSubscriptionId',
    billingPeriodStart: 'billingPeriodStart',
    meetingsThisMonth: 'meetingsThisMonth',
    chatMessagesToday: 'chatMessagesToday',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const SlackInstallationScalarFieldEnum: {
    id: 'id',
    teamId: 'teamId',
    teamName: 'teamName',
    botToken: 'botToken',
    installedBy: 'installedBy',
    installerName: 'installerName',
    active: 'active',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SlackInstallationScalarFieldEnum = (typeof SlackInstallationScalarFieldEnum)[keyof typeof SlackInstallationScalarFieldEnum]


  export const MeetingScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    title: 'title',
    description: 'description',
    meetingUrl: 'meetingUrl',
    startTime: 'startTime',
    endTime: 'endTime',
    attendees: 'attendees',
    calendarEventId: 'calendarEventId',
    isFromCalendar: 'isFromCalendar',
    botScheduled: 'botScheduled',
    botSent: 'botSent',
    botId: 'botId',
    botJoinedAt: 'botJoinedAt',
    meetingEnded: 'meetingEnded',
    transcriptReady: 'transcriptReady',
    transcript: 'transcript',
    recordingUrl: 'recordingUrl',
    speakers: 'speakers',
    summary: 'summary',
    actionItems: 'actionItems',
    processed: 'processed',
    processedAt: 'processedAt',
    emailSent: 'emailSent',
    emailSentAt: 'emailSentAt',
    ragProcessed: 'ragProcessed',
    ragProcessedAt: 'ragProcessedAt',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type MeetingScalarFieldEnum = (typeof MeetingScalarFieldEnum)[keyof typeof MeetingScalarFieldEnum]


  export const UserIntegrationScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    platform: 'platform',
    accessToken: 'accessToken',
    refreshToken: 'refreshToken',
    expiresAt: 'expiresAt',
    boardId: 'boardId',
    boardName: 'boardName',
    projectId: 'projectId',
    projectName: 'projectName',
    workspaceId: 'workspaceId',
    domain: 'domain',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserIntegrationScalarFieldEnum = (typeof UserIntegrationScalarFieldEnum)[keyof typeof UserIntegrationScalarFieldEnum]


  export const TranscriptChunkScalarFieldEnum: {
    id: 'id',
    meetingId: 'meetingId',
    chunkIndex: 'chunkIndex',
    content: 'content',
    speakerName: 'speakerName',
    vectorId: 'vectorId',
    createdAt: 'createdAt'
  };

  export type TranscriptChunkScalarFieldEnum = (typeof TranscriptChunkScalarFieldEnum)[keyof typeof TranscriptChunkScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    clerkId?: StringFilter<"User"> | string
    email?: StringNullableFilter<"User"> | string | null
    name?: StringNullableFilter<"User"> | string | null
    botName?: StringNullableFilter<"User"> | string | null
    botImageUrl?: StringNullableFilter<"User"> | string | null
    googleAccessToken?: StringNullableFilter<"User"> | string | null
    googleRefreshToken?: StringNullableFilter<"User"> | string | null
    googleTokenExpiry?: DateTimeNullableFilter<"User"> | Date | string | null
    calendarConnected?: BoolFilter<"User"> | boolean
    slackUserId?: StringNullableFilter<"User"> | string | null
    slackTeamId?: StringNullableFilter<"User"> | string | null
    slackConnected?: BoolFilter<"User"> | boolean
    preferredChannelId?: StringNullableFilter<"User"> | string | null
    preferredChannelName?: StringNullableFilter<"User"> | string | null
    currentPlan?: StringFilter<"User"> | string
    subscriptionStatus?: StringFilter<"User"> | string
    stripeCustomerId?: StringNullableFilter<"User"> | string | null
    stripeSubscriptionId?: StringNullableFilter<"User"> | string | null
    billingPeriodStart?: DateTimeNullableFilter<"User"> | Date | string | null
    meetingsThisMonth?: IntFilter<"User"> | number
    chatMessagesToday?: IntFilter<"User"> | number
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    meetings?: MeetingListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    clerkId?: SortOrder
    email?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    botName?: SortOrderInput | SortOrder
    botImageUrl?: SortOrderInput | SortOrder
    googleAccessToken?: SortOrderInput | SortOrder
    googleRefreshToken?: SortOrderInput | SortOrder
    googleTokenExpiry?: SortOrderInput | SortOrder
    calendarConnected?: SortOrder
    slackUserId?: SortOrderInput | SortOrder
    slackTeamId?: SortOrderInput | SortOrder
    slackConnected?: SortOrder
    preferredChannelId?: SortOrderInput | SortOrder
    preferredChannelName?: SortOrderInput | SortOrder
    currentPlan?: SortOrder
    subscriptionStatus?: SortOrder
    stripeCustomerId?: SortOrderInput | SortOrder
    stripeSubscriptionId?: SortOrderInput | SortOrder
    billingPeriodStart?: SortOrderInput | SortOrder
    meetingsThisMonth?: SortOrder
    chatMessagesToday?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    meetings?: MeetingOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    clerkId?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    email?: StringNullableFilter<"User"> | string | null
    name?: StringNullableFilter<"User"> | string | null
    botName?: StringNullableFilter<"User"> | string | null
    botImageUrl?: StringNullableFilter<"User"> | string | null
    googleAccessToken?: StringNullableFilter<"User"> | string | null
    googleRefreshToken?: StringNullableFilter<"User"> | string | null
    googleTokenExpiry?: DateTimeNullableFilter<"User"> | Date | string | null
    calendarConnected?: BoolFilter<"User"> | boolean
    slackUserId?: StringNullableFilter<"User"> | string | null
    slackTeamId?: StringNullableFilter<"User"> | string | null
    slackConnected?: BoolFilter<"User"> | boolean
    preferredChannelId?: StringNullableFilter<"User"> | string | null
    preferredChannelName?: StringNullableFilter<"User"> | string | null
    currentPlan?: StringFilter<"User"> | string
    subscriptionStatus?: StringFilter<"User"> | string
    stripeCustomerId?: StringNullableFilter<"User"> | string | null
    stripeSubscriptionId?: StringNullableFilter<"User"> | string | null
    billingPeriodStart?: DateTimeNullableFilter<"User"> | Date | string | null
    meetingsThisMonth?: IntFilter<"User"> | number
    chatMessagesToday?: IntFilter<"User"> | number
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    meetings?: MeetingListRelationFilter
  }, "id" | "clerkId">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    clerkId?: SortOrder
    email?: SortOrderInput | SortOrder
    name?: SortOrderInput | SortOrder
    botName?: SortOrderInput | SortOrder
    botImageUrl?: SortOrderInput | SortOrder
    googleAccessToken?: SortOrderInput | SortOrder
    googleRefreshToken?: SortOrderInput | SortOrder
    googleTokenExpiry?: SortOrderInput | SortOrder
    calendarConnected?: SortOrder
    slackUserId?: SortOrderInput | SortOrder
    slackTeamId?: SortOrderInput | SortOrder
    slackConnected?: SortOrder
    preferredChannelId?: SortOrderInput | SortOrder
    preferredChannelName?: SortOrderInput | SortOrder
    currentPlan?: SortOrder
    subscriptionStatus?: SortOrder
    stripeCustomerId?: SortOrderInput | SortOrder
    stripeSubscriptionId?: SortOrderInput | SortOrder
    billingPeriodStart?: SortOrderInput | SortOrder
    meetingsThisMonth?: SortOrder
    chatMessagesToday?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _avg?: UserAvgOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
    _sum?: UserSumOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    clerkId?: StringWithAggregatesFilter<"User"> | string
    email?: StringNullableWithAggregatesFilter<"User"> | string | null
    name?: StringNullableWithAggregatesFilter<"User"> | string | null
    botName?: StringNullableWithAggregatesFilter<"User"> | string | null
    botImageUrl?: StringNullableWithAggregatesFilter<"User"> | string | null
    googleAccessToken?: StringNullableWithAggregatesFilter<"User"> | string | null
    googleRefreshToken?: StringNullableWithAggregatesFilter<"User"> | string | null
    googleTokenExpiry?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
    calendarConnected?: BoolWithAggregatesFilter<"User"> | boolean
    slackUserId?: StringNullableWithAggregatesFilter<"User"> | string | null
    slackTeamId?: StringNullableWithAggregatesFilter<"User"> | string | null
    slackConnected?: BoolWithAggregatesFilter<"User"> | boolean
    preferredChannelId?: StringNullableWithAggregatesFilter<"User"> | string | null
    preferredChannelName?: StringNullableWithAggregatesFilter<"User"> | string | null
    currentPlan?: StringWithAggregatesFilter<"User"> | string
    subscriptionStatus?: StringWithAggregatesFilter<"User"> | string
    stripeCustomerId?: StringNullableWithAggregatesFilter<"User"> | string | null
    stripeSubscriptionId?: StringNullableWithAggregatesFilter<"User"> | string | null
    billingPeriodStart?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
    meetingsThisMonth?: IntWithAggregatesFilter<"User"> | number
    chatMessagesToday?: IntWithAggregatesFilter<"User"> | number
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type SlackInstallationWhereInput = {
    AND?: SlackInstallationWhereInput | SlackInstallationWhereInput[]
    OR?: SlackInstallationWhereInput[]
    NOT?: SlackInstallationWhereInput | SlackInstallationWhereInput[]
    id?: StringFilter<"SlackInstallation"> | string
    teamId?: StringFilter<"SlackInstallation"> | string
    teamName?: StringFilter<"SlackInstallation"> | string
    botToken?: StringFilter<"SlackInstallation"> | string
    installedBy?: StringFilter<"SlackInstallation"> | string
    installerName?: StringNullableFilter<"SlackInstallation"> | string | null
    active?: BoolFilter<"SlackInstallation"> | boolean
    createdAt?: DateTimeFilter<"SlackInstallation"> | Date | string
    updatedAt?: DateTimeFilter<"SlackInstallation"> | Date | string
  }

  export type SlackInstallationOrderByWithRelationInput = {
    id?: SortOrder
    teamId?: SortOrder
    teamName?: SortOrder
    botToken?: SortOrder
    installedBy?: SortOrder
    installerName?: SortOrderInput | SortOrder
    active?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SlackInstallationWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    teamId?: string
    AND?: SlackInstallationWhereInput | SlackInstallationWhereInput[]
    OR?: SlackInstallationWhereInput[]
    NOT?: SlackInstallationWhereInput | SlackInstallationWhereInput[]
    teamName?: StringFilter<"SlackInstallation"> | string
    botToken?: StringFilter<"SlackInstallation"> | string
    installedBy?: StringFilter<"SlackInstallation"> | string
    installerName?: StringNullableFilter<"SlackInstallation"> | string | null
    active?: BoolFilter<"SlackInstallation"> | boolean
    createdAt?: DateTimeFilter<"SlackInstallation"> | Date | string
    updatedAt?: DateTimeFilter<"SlackInstallation"> | Date | string
  }, "id" | "teamId">

  export type SlackInstallationOrderByWithAggregationInput = {
    id?: SortOrder
    teamId?: SortOrder
    teamName?: SortOrder
    botToken?: SortOrder
    installedBy?: SortOrder
    installerName?: SortOrderInput | SortOrder
    active?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SlackInstallationCountOrderByAggregateInput
    _max?: SlackInstallationMaxOrderByAggregateInput
    _min?: SlackInstallationMinOrderByAggregateInput
  }

  export type SlackInstallationScalarWhereWithAggregatesInput = {
    AND?: SlackInstallationScalarWhereWithAggregatesInput | SlackInstallationScalarWhereWithAggregatesInput[]
    OR?: SlackInstallationScalarWhereWithAggregatesInput[]
    NOT?: SlackInstallationScalarWhereWithAggregatesInput | SlackInstallationScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"SlackInstallation"> | string
    teamId?: StringWithAggregatesFilter<"SlackInstallation"> | string
    teamName?: StringWithAggregatesFilter<"SlackInstallation"> | string
    botToken?: StringWithAggregatesFilter<"SlackInstallation"> | string
    installedBy?: StringWithAggregatesFilter<"SlackInstallation"> | string
    installerName?: StringNullableWithAggregatesFilter<"SlackInstallation"> | string | null
    active?: BoolWithAggregatesFilter<"SlackInstallation"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"SlackInstallation"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"SlackInstallation"> | Date | string
  }

  export type MeetingWhereInput = {
    AND?: MeetingWhereInput | MeetingWhereInput[]
    OR?: MeetingWhereInput[]
    NOT?: MeetingWhereInput | MeetingWhereInput[]
    id?: StringFilter<"Meeting"> | string
    userId?: StringFilter<"Meeting"> | string
    title?: StringFilter<"Meeting"> | string
    description?: StringNullableFilter<"Meeting"> | string | null
    meetingUrl?: StringNullableFilter<"Meeting"> | string | null
    startTime?: DateTimeFilter<"Meeting"> | Date | string
    endTime?: DateTimeFilter<"Meeting"> | Date | string
    attendees?: JsonNullableFilter<"Meeting">
    calendarEventId?: StringNullableFilter<"Meeting"> | string | null
    isFromCalendar?: BoolFilter<"Meeting"> | boolean
    botScheduled?: BoolFilter<"Meeting"> | boolean
    botSent?: BoolFilter<"Meeting"> | boolean
    botId?: StringNullableFilter<"Meeting"> | string | null
    botJoinedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    meetingEnded?: BoolFilter<"Meeting"> | boolean
    transcriptReady?: BoolFilter<"Meeting"> | boolean
    transcript?: JsonNullableFilter<"Meeting">
    recordingUrl?: StringNullableFilter<"Meeting"> | string | null
    speakers?: JsonNullableFilter<"Meeting">
    summary?: StringNullableFilter<"Meeting"> | string | null
    actionItems?: JsonNullableFilter<"Meeting">
    processed?: BoolFilter<"Meeting"> | boolean
    processedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    emailSent?: BoolFilter<"Meeting"> | boolean
    emailSentAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    ragProcessed?: BoolFilter<"Meeting"> | boolean
    ragProcessedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    createdAt?: DateTimeFilter<"Meeting"> | Date | string
    updatedAt?: DateTimeFilter<"Meeting"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    TranscriptChunk?: TranscriptChunkListRelationFilter
  }

  export type MeetingOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    title?: SortOrder
    description?: SortOrderInput | SortOrder
    meetingUrl?: SortOrderInput | SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    attendees?: SortOrderInput | SortOrder
    calendarEventId?: SortOrderInput | SortOrder
    isFromCalendar?: SortOrder
    botScheduled?: SortOrder
    botSent?: SortOrder
    botId?: SortOrderInput | SortOrder
    botJoinedAt?: SortOrderInput | SortOrder
    meetingEnded?: SortOrder
    transcriptReady?: SortOrder
    transcript?: SortOrderInput | SortOrder
    recordingUrl?: SortOrderInput | SortOrder
    speakers?: SortOrderInput | SortOrder
    summary?: SortOrderInput | SortOrder
    actionItems?: SortOrderInput | SortOrder
    processed?: SortOrder
    processedAt?: SortOrderInput | SortOrder
    emailSent?: SortOrder
    emailSentAt?: SortOrderInput | SortOrder
    ragProcessed?: SortOrder
    ragProcessedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    TranscriptChunk?: TranscriptChunkOrderByRelationAggregateInput
  }

  export type MeetingWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    calendarEventId?: string
    AND?: MeetingWhereInput | MeetingWhereInput[]
    OR?: MeetingWhereInput[]
    NOT?: MeetingWhereInput | MeetingWhereInput[]
    userId?: StringFilter<"Meeting"> | string
    title?: StringFilter<"Meeting"> | string
    description?: StringNullableFilter<"Meeting"> | string | null
    meetingUrl?: StringNullableFilter<"Meeting"> | string | null
    startTime?: DateTimeFilter<"Meeting"> | Date | string
    endTime?: DateTimeFilter<"Meeting"> | Date | string
    attendees?: JsonNullableFilter<"Meeting">
    isFromCalendar?: BoolFilter<"Meeting"> | boolean
    botScheduled?: BoolFilter<"Meeting"> | boolean
    botSent?: BoolFilter<"Meeting"> | boolean
    botId?: StringNullableFilter<"Meeting"> | string | null
    botJoinedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    meetingEnded?: BoolFilter<"Meeting"> | boolean
    transcriptReady?: BoolFilter<"Meeting"> | boolean
    transcript?: JsonNullableFilter<"Meeting">
    recordingUrl?: StringNullableFilter<"Meeting"> | string | null
    speakers?: JsonNullableFilter<"Meeting">
    summary?: StringNullableFilter<"Meeting"> | string | null
    actionItems?: JsonNullableFilter<"Meeting">
    processed?: BoolFilter<"Meeting"> | boolean
    processedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    emailSent?: BoolFilter<"Meeting"> | boolean
    emailSentAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    ragProcessed?: BoolFilter<"Meeting"> | boolean
    ragProcessedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    createdAt?: DateTimeFilter<"Meeting"> | Date | string
    updatedAt?: DateTimeFilter<"Meeting"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    TranscriptChunk?: TranscriptChunkListRelationFilter
  }, "id" | "calendarEventId">

  export type MeetingOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    title?: SortOrder
    description?: SortOrderInput | SortOrder
    meetingUrl?: SortOrderInput | SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    attendees?: SortOrderInput | SortOrder
    calendarEventId?: SortOrderInput | SortOrder
    isFromCalendar?: SortOrder
    botScheduled?: SortOrder
    botSent?: SortOrder
    botId?: SortOrderInput | SortOrder
    botJoinedAt?: SortOrderInput | SortOrder
    meetingEnded?: SortOrder
    transcriptReady?: SortOrder
    transcript?: SortOrderInput | SortOrder
    recordingUrl?: SortOrderInput | SortOrder
    speakers?: SortOrderInput | SortOrder
    summary?: SortOrderInput | SortOrder
    actionItems?: SortOrderInput | SortOrder
    processed?: SortOrder
    processedAt?: SortOrderInput | SortOrder
    emailSent?: SortOrder
    emailSentAt?: SortOrderInput | SortOrder
    ragProcessed?: SortOrder
    ragProcessedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: MeetingCountOrderByAggregateInput
    _max?: MeetingMaxOrderByAggregateInput
    _min?: MeetingMinOrderByAggregateInput
  }

  export type MeetingScalarWhereWithAggregatesInput = {
    AND?: MeetingScalarWhereWithAggregatesInput | MeetingScalarWhereWithAggregatesInput[]
    OR?: MeetingScalarWhereWithAggregatesInput[]
    NOT?: MeetingScalarWhereWithAggregatesInput | MeetingScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Meeting"> | string
    userId?: StringWithAggregatesFilter<"Meeting"> | string
    title?: StringWithAggregatesFilter<"Meeting"> | string
    description?: StringNullableWithAggregatesFilter<"Meeting"> | string | null
    meetingUrl?: StringNullableWithAggregatesFilter<"Meeting"> | string | null
    startTime?: DateTimeWithAggregatesFilter<"Meeting"> | Date | string
    endTime?: DateTimeWithAggregatesFilter<"Meeting"> | Date | string
    attendees?: JsonNullableWithAggregatesFilter<"Meeting">
    calendarEventId?: StringNullableWithAggregatesFilter<"Meeting"> | string | null
    isFromCalendar?: BoolWithAggregatesFilter<"Meeting"> | boolean
    botScheduled?: BoolWithAggregatesFilter<"Meeting"> | boolean
    botSent?: BoolWithAggregatesFilter<"Meeting"> | boolean
    botId?: StringNullableWithAggregatesFilter<"Meeting"> | string | null
    botJoinedAt?: DateTimeNullableWithAggregatesFilter<"Meeting"> | Date | string | null
    meetingEnded?: BoolWithAggregatesFilter<"Meeting"> | boolean
    transcriptReady?: BoolWithAggregatesFilter<"Meeting"> | boolean
    transcript?: JsonNullableWithAggregatesFilter<"Meeting">
    recordingUrl?: StringNullableWithAggregatesFilter<"Meeting"> | string | null
    speakers?: JsonNullableWithAggregatesFilter<"Meeting">
    summary?: StringNullableWithAggregatesFilter<"Meeting"> | string | null
    actionItems?: JsonNullableWithAggregatesFilter<"Meeting">
    processed?: BoolWithAggregatesFilter<"Meeting"> | boolean
    processedAt?: DateTimeNullableWithAggregatesFilter<"Meeting"> | Date | string | null
    emailSent?: BoolWithAggregatesFilter<"Meeting"> | boolean
    emailSentAt?: DateTimeNullableWithAggregatesFilter<"Meeting"> | Date | string | null
    ragProcessed?: BoolWithAggregatesFilter<"Meeting"> | boolean
    ragProcessedAt?: DateTimeNullableWithAggregatesFilter<"Meeting"> | Date | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Meeting"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Meeting"> | Date | string
  }

  export type UserIntegrationWhereInput = {
    AND?: UserIntegrationWhereInput | UserIntegrationWhereInput[]
    OR?: UserIntegrationWhereInput[]
    NOT?: UserIntegrationWhereInput | UserIntegrationWhereInput[]
    id?: StringFilter<"UserIntegration"> | string
    userId?: StringFilter<"UserIntegration"> | string
    platform?: StringFilter<"UserIntegration"> | string
    accessToken?: StringFilter<"UserIntegration"> | string
    refreshToken?: StringNullableFilter<"UserIntegration"> | string | null
    expiresAt?: DateTimeNullableFilter<"UserIntegration"> | Date | string | null
    boardId?: StringNullableFilter<"UserIntegration"> | string | null
    boardName?: StringNullableFilter<"UserIntegration"> | string | null
    projectId?: StringNullableFilter<"UserIntegration"> | string | null
    projectName?: StringNullableFilter<"UserIntegration"> | string | null
    workspaceId?: StringNullableFilter<"UserIntegration"> | string | null
    domain?: StringNullableFilter<"UserIntegration"> | string | null
    createdAt?: DateTimeFilter<"UserIntegration"> | Date | string
    updatedAt?: DateTimeFilter<"UserIntegration"> | Date | string
  }

  export type UserIntegrationOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    platform?: SortOrder
    accessToken?: SortOrder
    refreshToken?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    boardId?: SortOrderInput | SortOrder
    boardName?: SortOrderInput | SortOrder
    projectId?: SortOrderInput | SortOrder
    projectName?: SortOrderInput | SortOrder
    workspaceId?: SortOrderInput | SortOrder
    domain?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserIntegrationWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    userId_platform?: UserIntegrationUserIdPlatformCompoundUniqueInput
    AND?: UserIntegrationWhereInput | UserIntegrationWhereInput[]
    OR?: UserIntegrationWhereInput[]
    NOT?: UserIntegrationWhereInput | UserIntegrationWhereInput[]
    userId?: StringFilter<"UserIntegration"> | string
    platform?: StringFilter<"UserIntegration"> | string
    accessToken?: StringFilter<"UserIntegration"> | string
    refreshToken?: StringNullableFilter<"UserIntegration"> | string | null
    expiresAt?: DateTimeNullableFilter<"UserIntegration"> | Date | string | null
    boardId?: StringNullableFilter<"UserIntegration"> | string | null
    boardName?: StringNullableFilter<"UserIntegration"> | string | null
    projectId?: StringNullableFilter<"UserIntegration"> | string | null
    projectName?: StringNullableFilter<"UserIntegration"> | string | null
    workspaceId?: StringNullableFilter<"UserIntegration"> | string | null
    domain?: StringNullableFilter<"UserIntegration"> | string | null
    createdAt?: DateTimeFilter<"UserIntegration"> | Date | string
    updatedAt?: DateTimeFilter<"UserIntegration"> | Date | string
  }, "id" | "userId_platform">

  export type UserIntegrationOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    platform?: SortOrder
    accessToken?: SortOrder
    refreshToken?: SortOrderInput | SortOrder
    expiresAt?: SortOrderInput | SortOrder
    boardId?: SortOrderInput | SortOrder
    boardName?: SortOrderInput | SortOrder
    projectId?: SortOrderInput | SortOrder
    projectName?: SortOrderInput | SortOrder
    workspaceId?: SortOrderInput | SortOrder
    domain?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserIntegrationCountOrderByAggregateInput
    _max?: UserIntegrationMaxOrderByAggregateInput
    _min?: UserIntegrationMinOrderByAggregateInput
  }

  export type UserIntegrationScalarWhereWithAggregatesInput = {
    AND?: UserIntegrationScalarWhereWithAggregatesInput | UserIntegrationScalarWhereWithAggregatesInput[]
    OR?: UserIntegrationScalarWhereWithAggregatesInput[]
    NOT?: UserIntegrationScalarWhereWithAggregatesInput | UserIntegrationScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"UserIntegration"> | string
    userId?: StringWithAggregatesFilter<"UserIntegration"> | string
    platform?: StringWithAggregatesFilter<"UserIntegration"> | string
    accessToken?: StringWithAggregatesFilter<"UserIntegration"> | string
    refreshToken?: StringNullableWithAggregatesFilter<"UserIntegration"> | string | null
    expiresAt?: DateTimeNullableWithAggregatesFilter<"UserIntegration"> | Date | string | null
    boardId?: StringNullableWithAggregatesFilter<"UserIntegration"> | string | null
    boardName?: StringNullableWithAggregatesFilter<"UserIntegration"> | string | null
    projectId?: StringNullableWithAggregatesFilter<"UserIntegration"> | string | null
    projectName?: StringNullableWithAggregatesFilter<"UserIntegration"> | string | null
    workspaceId?: StringNullableWithAggregatesFilter<"UserIntegration"> | string | null
    domain?: StringNullableWithAggregatesFilter<"UserIntegration"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"UserIntegration"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"UserIntegration"> | Date | string
  }

  export type TranscriptChunkWhereInput = {
    AND?: TranscriptChunkWhereInput | TranscriptChunkWhereInput[]
    OR?: TranscriptChunkWhereInput[]
    NOT?: TranscriptChunkWhereInput | TranscriptChunkWhereInput[]
    id?: StringFilter<"TranscriptChunk"> | string
    meetingId?: StringFilter<"TranscriptChunk"> | string
    chunkIndex?: IntFilter<"TranscriptChunk"> | number
    content?: StringFilter<"TranscriptChunk"> | string
    speakerName?: StringNullableFilter<"TranscriptChunk"> | string | null
    vectorId?: StringNullableFilter<"TranscriptChunk"> | string | null
    createdAt?: DateTimeFilter<"TranscriptChunk"> | Date | string
    meeting?: XOR<MeetingScalarRelationFilter, MeetingWhereInput>
  }

  export type TranscriptChunkOrderByWithRelationInput = {
    id?: SortOrder
    meetingId?: SortOrder
    chunkIndex?: SortOrder
    content?: SortOrder
    speakerName?: SortOrderInput | SortOrder
    vectorId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    meeting?: MeetingOrderByWithRelationInput
  }

  export type TranscriptChunkWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TranscriptChunkWhereInput | TranscriptChunkWhereInput[]
    OR?: TranscriptChunkWhereInput[]
    NOT?: TranscriptChunkWhereInput | TranscriptChunkWhereInput[]
    meetingId?: StringFilter<"TranscriptChunk"> | string
    chunkIndex?: IntFilter<"TranscriptChunk"> | number
    content?: StringFilter<"TranscriptChunk"> | string
    speakerName?: StringNullableFilter<"TranscriptChunk"> | string | null
    vectorId?: StringNullableFilter<"TranscriptChunk"> | string | null
    createdAt?: DateTimeFilter<"TranscriptChunk"> | Date | string
    meeting?: XOR<MeetingScalarRelationFilter, MeetingWhereInput>
  }, "id">

  export type TranscriptChunkOrderByWithAggregationInput = {
    id?: SortOrder
    meetingId?: SortOrder
    chunkIndex?: SortOrder
    content?: SortOrder
    speakerName?: SortOrderInput | SortOrder
    vectorId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: TranscriptChunkCountOrderByAggregateInput
    _avg?: TranscriptChunkAvgOrderByAggregateInput
    _max?: TranscriptChunkMaxOrderByAggregateInput
    _min?: TranscriptChunkMinOrderByAggregateInput
    _sum?: TranscriptChunkSumOrderByAggregateInput
  }

  export type TranscriptChunkScalarWhereWithAggregatesInput = {
    AND?: TranscriptChunkScalarWhereWithAggregatesInput | TranscriptChunkScalarWhereWithAggregatesInput[]
    OR?: TranscriptChunkScalarWhereWithAggregatesInput[]
    NOT?: TranscriptChunkScalarWhereWithAggregatesInput | TranscriptChunkScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"TranscriptChunk"> | string
    meetingId?: StringWithAggregatesFilter<"TranscriptChunk"> | string
    chunkIndex?: IntWithAggregatesFilter<"TranscriptChunk"> | number
    content?: StringWithAggregatesFilter<"TranscriptChunk"> | string
    speakerName?: StringNullableWithAggregatesFilter<"TranscriptChunk"> | string | null
    vectorId?: StringNullableWithAggregatesFilter<"TranscriptChunk"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"TranscriptChunk"> | Date | string
  }

  export type UserCreateInput = {
    id: string
    clerkId: string
    email?: string | null
    name?: string | null
    botName?: string | null
    botImageUrl?: string | null
    googleAccessToken?: string | null
    googleRefreshToken?: string | null
    googleTokenExpiry?: Date | string | null
    calendarConnected?: boolean
    slackUserId?: string | null
    slackTeamId?: string | null
    slackConnected?: boolean
    preferredChannelId?: string | null
    preferredChannelName?: string | null
    currentPlan?: string
    subscriptionStatus?: string
    stripeCustomerId?: string | null
    stripeSubscriptionId?: string | null
    billingPeriodStart?: Date | string | null
    meetingsThisMonth?: number
    chatMessagesToday?: number
    createdAt?: Date | string
    updatedAt?: Date | string
    meetings?: MeetingCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id: string
    clerkId: string
    email?: string | null
    name?: string | null
    botName?: string | null
    botImageUrl?: string | null
    googleAccessToken?: string | null
    googleRefreshToken?: string | null
    googleTokenExpiry?: Date | string | null
    calendarConnected?: boolean
    slackUserId?: string | null
    slackTeamId?: string | null
    slackConnected?: boolean
    preferredChannelId?: string | null
    preferredChannelName?: string | null
    currentPlan?: string
    subscriptionStatus?: string
    stripeCustomerId?: string | null
    stripeSubscriptionId?: string | null
    billingPeriodStart?: Date | string | null
    meetingsThisMonth?: number
    chatMessagesToday?: number
    createdAt?: Date | string
    updatedAt?: Date | string
    meetings?: MeetingUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    clerkId?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    botName?: NullableStringFieldUpdateOperationsInput | string | null
    botImageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    googleAccessToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleRefreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleTokenExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    calendarConnected?: BoolFieldUpdateOperationsInput | boolean
    slackUserId?: NullableStringFieldUpdateOperationsInput | string | null
    slackTeamId?: NullableStringFieldUpdateOperationsInput | string | null
    slackConnected?: BoolFieldUpdateOperationsInput | boolean
    preferredChannelId?: NullableStringFieldUpdateOperationsInput | string | null
    preferredChannelName?: NullableStringFieldUpdateOperationsInput | string | null
    currentPlan?: StringFieldUpdateOperationsInput | string
    subscriptionStatus?: StringFieldUpdateOperationsInput | string
    stripeCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    stripeSubscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    billingPeriodStart?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingsThisMonth?: IntFieldUpdateOperationsInput | number
    chatMessagesToday?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meetings?: MeetingUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    clerkId?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    botName?: NullableStringFieldUpdateOperationsInput | string | null
    botImageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    googleAccessToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleRefreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleTokenExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    calendarConnected?: BoolFieldUpdateOperationsInput | boolean
    slackUserId?: NullableStringFieldUpdateOperationsInput | string | null
    slackTeamId?: NullableStringFieldUpdateOperationsInput | string | null
    slackConnected?: BoolFieldUpdateOperationsInput | boolean
    preferredChannelId?: NullableStringFieldUpdateOperationsInput | string | null
    preferredChannelName?: NullableStringFieldUpdateOperationsInput | string | null
    currentPlan?: StringFieldUpdateOperationsInput | string
    subscriptionStatus?: StringFieldUpdateOperationsInput | string
    stripeCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    stripeSubscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    billingPeriodStart?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingsThisMonth?: IntFieldUpdateOperationsInput | number
    chatMessagesToday?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meetings?: MeetingUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id: string
    clerkId: string
    email?: string | null
    name?: string | null
    botName?: string | null
    botImageUrl?: string | null
    googleAccessToken?: string | null
    googleRefreshToken?: string | null
    googleTokenExpiry?: Date | string | null
    calendarConnected?: boolean
    slackUserId?: string | null
    slackTeamId?: string | null
    slackConnected?: boolean
    preferredChannelId?: string | null
    preferredChannelName?: string | null
    currentPlan?: string
    subscriptionStatus?: string
    stripeCustomerId?: string | null
    stripeSubscriptionId?: string | null
    billingPeriodStart?: Date | string | null
    meetingsThisMonth?: number
    chatMessagesToday?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    clerkId?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    botName?: NullableStringFieldUpdateOperationsInput | string | null
    botImageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    googleAccessToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleRefreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleTokenExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    calendarConnected?: BoolFieldUpdateOperationsInput | boolean
    slackUserId?: NullableStringFieldUpdateOperationsInput | string | null
    slackTeamId?: NullableStringFieldUpdateOperationsInput | string | null
    slackConnected?: BoolFieldUpdateOperationsInput | boolean
    preferredChannelId?: NullableStringFieldUpdateOperationsInput | string | null
    preferredChannelName?: NullableStringFieldUpdateOperationsInput | string | null
    currentPlan?: StringFieldUpdateOperationsInput | string
    subscriptionStatus?: StringFieldUpdateOperationsInput | string
    stripeCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    stripeSubscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    billingPeriodStart?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingsThisMonth?: IntFieldUpdateOperationsInput | number
    chatMessagesToday?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    clerkId?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    botName?: NullableStringFieldUpdateOperationsInput | string | null
    botImageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    googleAccessToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleRefreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleTokenExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    calendarConnected?: BoolFieldUpdateOperationsInput | boolean
    slackUserId?: NullableStringFieldUpdateOperationsInput | string | null
    slackTeamId?: NullableStringFieldUpdateOperationsInput | string | null
    slackConnected?: BoolFieldUpdateOperationsInput | boolean
    preferredChannelId?: NullableStringFieldUpdateOperationsInput | string | null
    preferredChannelName?: NullableStringFieldUpdateOperationsInput | string | null
    currentPlan?: StringFieldUpdateOperationsInput | string
    subscriptionStatus?: StringFieldUpdateOperationsInput | string
    stripeCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    stripeSubscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    billingPeriodStart?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingsThisMonth?: IntFieldUpdateOperationsInput | number
    chatMessagesToday?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SlackInstallationCreateInput = {
    id?: string
    teamId: string
    teamName: string
    botToken: string
    installedBy: string
    installerName?: string | null
    active?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SlackInstallationUncheckedCreateInput = {
    id?: string
    teamId: string
    teamName: string
    botToken: string
    installedBy: string
    installerName?: string | null
    active?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SlackInstallationUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    teamId?: StringFieldUpdateOperationsInput | string
    teamName?: StringFieldUpdateOperationsInput | string
    botToken?: StringFieldUpdateOperationsInput | string
    installedBy?: StringFieldUpdateOperationsInput | string
    installerName?: NullableStringFieldUpdateOperationsInput | string | null
    active?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SlackInstallationUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    teamId?: StringFieldUpdateOperationsInput | string
    teamName?: StringFieldUpdateOperationsInput | string
    botToken?: StringFieldUpdateOperationsInput | string
    installedBy?: StringFieldUpdateOperationsInput | string
    installerName?: NullableStringFieldUpdateOperationsInput | string | null
    active?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SlackInstallationCreateManyInput = {
    id?: string
    teamId: string
    teamName: string
    botToken: string
    installedBy: string
    installerName?: string | null
    active?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SlackInstallationUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    teamId?: StringFieldUpdateOperationsInput | string
    teamName?: StringFieldUpdateOperationsInput | string
    botToken?: StringFieldUpdateOperationsInput | string
    installedBy?: StringFieldUpdateOperationsInput | string
    installerName?: NullableStringFieldUpdateOperationsInput | string | null
    active?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SlackInstallationUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    teamId?: StringFieldUpdateOperationsInput | string
    teamName?: StringFieldUpdateOperationsInput | string
    botToken?: StringFieldUpdateOperationsInput | string
    installedBy?: StringFieldUpdateOperationsInput | string
    installerName?: NullableStringFieldUpdateOperationsInput | string | null
    active?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MeetingCreateInput = {
    id?: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutMeetingsInput
    TranscriptChunk?: TranscriptChunkCreateNestedManyWithoutMeetingInput
  }

  export type MeetingUncheckedCreateInput = {
    id?: string
    userId: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    TranscriptChunk?: TranscriptChunkUncheckedCreateNestedManyWithoutMeetingInput
  }

  export type MeetingUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutMeetingsNestedInput
    TranscriptChunk?: TranscriptChunkUpdateManyWithoutMeetingNestedInput
  }

  export type MeetingUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TranscriptChunk?: TranscriptChunkUncheckedUpdateManyWithoutMeetingNestedInput
  }

  export type MeetingCreateManyInput = {
    id?: string
    userId: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MeetingUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MeetingUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserIntegrationCreateInput = {
    id?: string
    userId: string
    platform: string
    accessToken: string
    refreshToken?: string | null
    expiresAt?: Date | string | null
    boardId?: string | null
    boardName?: string | null
    projectId?: string | null
    projectName?: string | null
    workspaceId?: string | null
    domain?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserIntegrationUncheckedCreateInput = {
    id?: string
    userId: string
    platform: string
    accessToken: string
    refreshToken?: string | null
    expiresAt?: Date | string | null
    boardId?: string | null
    boardName?: string | null
    projectId?: string | null
    projectName?: string | null
    workspaceId?: string | null
    domain?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserIntegrationUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    platform?: StringFieldUpdateOperationsInput | string
    accessToken?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    boardId?: NullableStringFieldUpdateOperationsInput | string | null
    boardName?: NullableStringFieldUpdateOperationsInput | string | null
    projectId?: NullableStringFieldUpdateOperationsInput | string | null
    projectName?: NullableStringFieldUpdateOperationsInput | string | null
    workspaceId?: NullableStringFieldUpdateOperationsInput | string | null
    domain?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserIntegrationUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    platform?: StringFieldUpdateOperationsInput | string
    accessToken?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    boardId?: NullableStringFieldUpdateOperationsInput | string | null
    boardName?: NullableStringFieldUpdateOperationsInput | string | null
    projectId?: NullableStringFieldUpdateOperationsInput | string | null
    projectName?: NullableStringFieldUpdateOperationsInput | string | null
    workspaceId?: NullableStringFieldUpdateOperationsInput | string | null
    domain?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserIntegrationCreateManyInput = {
    id?: string
    userId: string
    platform: string
    accessToken: string
    refreshToken?: string | null
    expiresAt?: Date | string | null
    boardId?: string | null
    boardName?: string | null
    projectId?: string | null
    projectName?: string | null
    workspaceId?: string | null
    domain?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserIntegrationUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    platform?: StringFieldUpdateOperationsInput | string
    accessToken?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    boardId?: NullableStringFieldUpdateOperationsInput | string | null
    boardName?: NullableStringFieldUpdateOperationsInput | string | null
    projectId?: NullableStringFieldUpdateOperationsInput | string | null
    projectName?: NullableStringFieldUpdateOperationsInput | string | null
    workspaceId?: NullableStringFieldUpdateOperationsInput | string | null
    domain?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserIntegrationUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    platform?: StringFieldUpdateOperationsInput | string
    accessToken?: StringFieldUpdateOperationsInput | string
    refreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    boardId?: NullableStringFieldUpdateOperationsInput | string | null
    boardName?: NullableStringFieldUpdateOperationsInput | string | null
    projectId?: NullableStringFieldUpdateOperationsInput | string | null
    projectName?: NullableStringFieldUpdateOperationsInput | string | null
    workspaceId?: NullableStringFieldUpdateOperationsInput | string | null
    domain?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TranscriptChunkCreateInput = {
    id?: string
    chunkIndex: number
    content: string
    speakerName?: string | null
    vectorId?: string | null
    createdAt?: Date | string
    meeting: MeetingCreateNestedOneWithoutTranscriptChunkInput
  }

  export type TranscriptChunkUncheckedCreateInput = {
    id?: string
    meetingId: string
    chunkIndex: number
    content: string
    speakerName?: string | null
    vectorId?: string | null
    createdAt?: Date | string
  }

  export type TranscriptChunkUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    chunkIndex?: IntFieldUpdateOperationsInput | number
    content?: StringFieldUpdateOperationsInput | string
    speakerName?: NullableStringFieldUpdateOperationsInput | string | null
    vectorId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    meeting?: MeetingUpdateOneRequiredWithoutTranscriptChunkNestedInput
  }

  export type TranscriptChunkUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    meetingId?: StringFieldUpdateOperationsInput | string
    chunkIndex?: IntFieldUpdateOperationsInput | number
    content?: StringFieldUpdateOperationsInput | string
    speakerName?: NullableStringFieldUpdateOperationsInput | string | null
    vectorId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TranscriptChunkCreateManyInput = {
    id?: string
    meetingId: string
    chunkIndex: number
    content: string
    speakerName?: string | null
    vectorId?: string | null
    createdAt?: Date | string
  }

  export type TranscriptChunkUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    chunkIndex?: IntFieldUpdateOperationsInput | number
    content?: StringFieldUpdateOperationsInput | string
    speakerName?: NullableStringFieldUpdateOperationsInput | string | null
    vectorId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TranscriptChunkUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    meetingId?: StringFieldUpdateOperationsInput | string
    chunkIndex?: IntFieldUpdateOperationsInput | number
    content?: StringFieldUpdateOperationsInput | string
    speakerName?: NullableStringFieldUpdateOperationsInput | string | null
    vectorId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type MeetingListRelationFilter = {
    every?: MeetingWhereInput
    some?: MeetingWhereInput
    none?: MeetingWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type MeetingOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    clerkId?: SortOrder
    email?: SortOrder
    name?: SortOrder
    botName?: SortOrder
    botImageUrl?: SortOrder
    googleAccessToken?: SortOrder
    googleRefreshToken?: SortOrder
    googleTokenExpiry?: SortOrder
    calendarConnected?: SortOrder
    slackUserId?: SortOrder
    slackTeamId?: SortOrder
    slackConnected?: SortOrder
    preferredChannelId?: SortOrder
    preferredChannelName?: SortOrder
    currentPlan?: SortOrder
    subscriptionStatus?: SortOrder
    stripeCustomerId?: SortOrder
    stripeSubscriptionId?: SortOrder
    billingPeriodStart?: SortOrder
    meetingsThisMonth?: SortOrder
    chatMessagesToday?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserAvgOrderByAggregateInput = {
    meetingsThisMonth?: SortOrder
    chatMessagesToday?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    clerkId?: SortOrder
    email?: SortOrder
    name?: SortOrder
    botName?: SortOrder
    botImageUrl?: SortOrder
    googleAccessToken?: SortOrder
    googleRefreshToken?: SortOrder
    googleTokenExpiry?: SortOrder
    calendarConnected?: SortOrder
    slackUserId?: SortOrder
    slackTeamId?: SortOrder
    slackConnected?: SortOrder
    preferredChannelId?: SortOrder
    preferredChannelName?: SortOrder
    currentPlan?: SortOrder
    subscriptionStatus?: SortOrder
    stripeCustomerId?: SortOrder
    stripeSubscriptionId?: SortOrder
    billingPeriodStart?: SortOrder
    meetingsThisMonth?: SortOrder
    chatMessagesToday?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    clerkId?: SortOrder
    email?: SortOrder
    name?: SortOrder
    botName?: SortOrder
    botImageUrl?: SortOrder
    googleAccessToken?: SortOrder
    googleRefreshToken?: SortOrder
    googleTokenExpiry?: SortOrder
    calendarConnected?: SortOrder
    slackUserId?: SortOrder
    slackTeamId?: SortOrder
    slackConnected?: SortOrder
    preferredChannelId?: SortOrder
    preferredChannelName?: SortOrder
    currentPlan?: SortOrder
    subscriptionStatus?: SortOrder
    stripeCustomerId?: SortOrder
    stripeSubscriptionId?: SortOrder
    billingPeriodStart?: SortOrder
    meetingsThisMonth?: SortOrder
    chatMessagesToday?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserSumOrderByAggregateInput = {
    meetingsThisMonth?: SortOrder
    chatMessagesToday?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type SlackInstallationCountOrderByAggregateInput = {
    id?: SortOrder
    teamId?: SortOrder
    teamName?: SortOrder
    botToken?: SortOrder
    installedBy?: SortOrder
    installerName?: SortOrder
    active?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SlackInstallationMaxOrderByAggregateInput = {
    id?: SortOrder
    teamId?: SortOrder
    teamName?: SortOrder
    botToken?: SortOrder
    installedBy?: SortOrder
    installerName?: SortOrder
    active?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SlackInstallationMinOrderByAggregateInput = {
    id?: SortOrder
    teamId?: SortOrder
    teamName?: SortOrder
    botToken?: SortOrder
    installedBy?: SortOrder
    installerName?: SortOrder
    active?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }
  export type JsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type TranscriptChunkListRelationFilter = {
    every?: TranscriptChunkWhereInput
    some?: TranscriptChunkWhereInput
    none?: TranscriptChunkWhereInput
  }

  export type TranscriptChunkOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MeetingCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    meetingUrl?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    attendees?: SortOrder
    calendarEventId?: SortOrder
    isFromCalendar?: SortOrder
    botScheduled?: SortOrder
    botSent?: SortOrder
    botId?: SortOrder
    botJoinedAt?: SortOrder
    meetingEnded?: SortOrder
    transcriptReady?: SortOrder
    transcript?: SortOrder
    recordingUrl?: SortOrder
    speakers?: SortOrder
    summary?: SortOrder
    actionItems?: SortOrder
    processed?: SortOrder
    processedAt?: SortOrder
    emailSent?: SortOrder
    emailSentAt?: SortOrder
    ragProcessed?: SortOrder
    ragProcessedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MeetingMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    meetingUrl?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    calendarEventId?: SortOrder
    isFromCalendar?: SortOrder
    botScheduled?: SortOrder
    botSent?: SortOrder
    botId?: SortOrder
    botJoinedAt?: SortOrder
    meetingEnded?: SortOrder
    transcriptReady?: SortOrder
    recordingUrl?: SortOrder
    summary?: SortOrder
    processed?: SortOrder
    processedAt?: SortOrder
    emailSent?: SortOrder
    emailSentAt?: SortOrder
    ragProcessed?: SortOrder
    ragProcessedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MeetingMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    title?: SortOrder
    description?: SortOrder
    meetingUrl?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    calendarEventId?: SortOrder
    isFromCalendar?: SortOrder
    botScheduled?: SortOrder
    botSent?: SortOrder
    botId?: SortOrder
    botJoinedAt?: SortOrder
    meetingEnded?: SortOrder
    transcriptReady?: SortOrder
    recordingUrl?: SortOrder
    summary?: SortOrder
    processed?: SortOrder
    processedAt?: SortOrder
    emailSent?: SortOrder
    emailSentAt?: SortOrder
    ragProcessed?: SortOrder
    ragProcessedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type UserIntegrationUserIdPlatformCompoundUniqueInput = {
    userId: string
    platform: string
  }

  export type UserIntegrationCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    platform?: SortOrder
    accessToken?: SortOrder
    refreshToken?: SortOrder
    expiresAt?: SortOrder
    boardId?: SortOrder
    boardName?: SortOrder
    projectId?: SortOrder
    projectName?: SortOrder
    workspaceId?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserIntegrationMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    platform?: SortOrder
    accessToken?: SortOrder
    refreshToken?: SortOrder
    expiresAt?: SortOrder
    boardId?: SortOrder
    boardName?: SortOrder
    projectId?: SortOrder
    projectName?: SortOrder
    workspaceId?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserIntegrationMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    platform?: SortOrder
    accessToken?: SortOrder
    refreshToken?: SortOrder
    expiresAt?: SortOrder
    boardId?: SortOrder
    boardName?: SortOrder
    projectId?: SortOrder
    projectName?: SortOrder
    workspaceId?: SortOrder
    domain?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MeetingScalarRelationFilter = {
    is?: MeetingWhereInput
    isNot?: MeetingWhereInput
  }

  export type TranscriptChunkCountOrderByAggregateInput = {
    id?: SortOrder
    meetingId?: SortOrder
    chunkIndex?: SortOrder
    content?: SortOrder
    speakerName?: SortOrder
    vectorId?: SortOrder
    createdAt?: SortOrder
  }

  export type TranscriptChunkAvgOrderByAggregateInput = {
    chunkIndex?: SortOrder
  }

  export type TranscriptChunkMaxOrderByAggregateInput = {
    id?: SortOrder
    meetingId?: SortOrder
    chunkIndex?: SortOrder
    content?: SortOrder
    speakerName?: SortOrder
    vectorId?: SortOrder
    createdAt?: SortOrder
  }

  export type TranscriptChunkMinOrderByAggregateInput = {
    id?: SortOrder
    meetingId?: SortOrder
    chunkIndex?: SortOrder
    content?: SortOrder
    speakerName?: SortOrder
    vectorId?: SortOrder
    createdAt?: SortOrder
  }

  export type TranscriptChunkSumOrderByAggregateInput = {
    chunkIndex?: SortOrder
  }

  export type MeetingCreateNestedManyWithoutUserInput = {
    create?: XOR<MeetingCreateWithoutUserInput, MeetingUncheckedCreateWithoutUserInput> | MeetingCreateWithoutUserInput[] | MeetingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MeetingCreateOrConnectWithoutUserInput | MeetingCreateOrConnectWithoutUserInput[]
    createMany?: MeetingCreateManyUserInputEnvelope
    connect?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
  }

  export type MeetingUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<MeetingCreateWithoutUserInput, MeetingUncheckedCreateWithoutUserInput> | MeetingCreateWithoutUserInput[] | MeetingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MeetingCreateOrConnectWithoutUserInput | MeetingCreateOrConnectWithoutUserInput[]
    createMany?: MeetingCreateManyUserInputEnvelope
    connect?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type MeetingUpdateManyWithoutUserNestedInput = {
    create?: XOR<MeetingCreateWithoutUserInput, MeetingUncheckedCreateWithoutUserInput> | MeetingCreateWithoutUserInput[] | MeetingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MeetingCreateOrConnectWithoutUserInput | MeetingCreateOrConnectWithoutUserInput[]
    upsert?: MeetingUpsertWithWhereUniqueWithoutUserInput | MeetingUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: MeetingCreateManyUserInputEnvelope
    set?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    disconnect?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    delete?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    connect?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    update?: MeetingUpdateWithWhereUniqueWithoutUserInput | MeetingUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: MeetingUpdateManyWithWhereWithoutUserInput | MeetingUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: MeetingScalarWhereInput | MeetingScalarWhereInput[]
  }

  export type MeetingUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<MeetingCreateWithoutUserInput, MeetingUncheckedCreateWithoutUserInput> | MeetingCreateWithoutUserInput[] | MeetingUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MeetingCreateOrConnectWithoutUserInput | MeetingCreateOrConnectWithoutUserInput[]
    upsert?: MeetingUpsertWithWhereUniqueWithoutUserInput | MeetingUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: MeetingCreateManyUserInputEnvelope
    set?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    disconnect?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    delete?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    connect?: MeetingWhereUniqueInput | MeetingWhereUniqueInput[]
    update?: MeetingUpdateWithWhereUniqueWithoutUserInput | MeetingUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: MeetingUpdateManyWithWhereWithoutUserInput | MeetingUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: MeetingScalarWhereInput | MeetingScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutMeetingsInput = {
    create?: XOR<UserCreateWithoutMeetingsInput, UserUncheckedCreateWithoutMeetingsInput>
    connectOrCreate?: UserCreateOrConnectWithoutMeetingsInput
    connect?: UserWhereUniqueInput
  }

  export type TranscriptChunkCreateNestedManyWithoutMeetingInput = {
    create?: XOR<TranscriptChunkCreateWithoutMeetingInput, TranscriptChunkUncheckedCreateWithoutMeetingInput> | TranscriptChunkCreateWithoutMeetingInput[] | TranscriptChunkUncheckedCreateWithoutMeetingInput[]
    connectOrCreate?: TranscriptChunkCreateOrConnectWithoutMeetingInput | TranscriptChunkCreateOrConnectWithoutMeetingInput[]
    createMany?: TranscriptChunkCreateManyMeetingInputEnvelope
    connect?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
  }

  export type TranscriptChunkUncheckedCreateNestedManyWithoutMeetingInput = {
    create?: XOR<TranscriptChunkCreateWithoutMeetingInput, TranscriptChunkUncheckedCreateWithoutMeetingInput> | TranscriptChunkCreateWithoutMeetingInput[] | TranscriptChunkUncheckedCreateWithoutMeetingInput[]
    connectOrCreate?: TranscriptChunkCreateOrConnectWithoutMeetingInput | TranscriptChunkCreateOrConnectWithoutMeetingInput[]
    createMany?: TranscriptChunkCreateManyMeetingInputEnvelope
    connect?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
  }

  export type UserUpdateOneRequiredWithoutMeetingsNestedInput = {
    create?: XOR<UserCreateWithoutMeetingsInput, UserUncheckedCreateWithoutMeetingsInput>
    connectOrCreate?: UserCreateOrConnectWithoutMeetingsInput
    upsert?: UserUpsertWithoutMeetingsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutMeetingsInput, UserUpdateWithoutMeetingsInput>, UserUncheckedUpdateWithoutMeetingsInput>
  }

  export type TranscriptChunkUpdateManyWithoutMeetingNestedInput = {
    create?: XOR<TranscriptChunkCreateWithoutMeetingInput, TranscriptChunkUncheckedCreateWithoutMeetingInput> | TranscriptChunkCreateWithoutMeetingInput[] | TranscriptChunkUncheckedCreateWithoutMeetingInput[]
    connectOrCreate?: TranscriptChunkCreateOrConnectWithoutMeetingInput | TranscriptChunkCreateOrConnectWithoutMeetingInput[]
    upsert?: TranscriptChunkUpsertWithWhereUniqueWithoutMeetingInput | TranscriptChunkUpsertWithWhereUniqueWithoutMeetingInput[]
    createMany?: TranscriptChunkCreateManyMeetingInputEnvelope
    set?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    disconnect?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    delete?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    connect?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    update?: TranscriptChunkUpdateWithWhereUniqueWithoutMeetingInput | TranscriptChunkUpdateWithWhereUniqueWithoutMeetingInput[]
    updateMany?: TranscriptChunkUpdateManyWithWhereWithoutMeetingInput | TranscriptChunkUpdateManyWithWhereWithoutMeetingInput[]
    deleteMany?: TranscriptChunkScalarWhereInput | TranscriptChunkScalarWhereInput[]
  }

  export type TranscriptChunkUncheckedUpdateManyWithoutMeetingNestedInput = {
    create?: XOR<TranscriptChunkCreateWithoutMeetingInput, TranscriptChunkUncheckedCreateWithoutMeetingInput> | TranscriptChunkCreateWithoutMeetingInput[] | TranscriptChunkUncheckedCreateWithoutMeetingInput[]
    connectOrCreate?: TranscriptChunkCreateOrConnectWithoutMeetingInput | TranscriptChunkCreateOrConnectWithoutMeetingInput[]
    upsert?: TranscriptChunkUpsertWithWhereUniqueWithoutMeetingInput | TranscriptChunkUpsertWithWhereUniqueWithoutMeetingInput[]
    createMany?: TranscriptChunkCreateManyMeetingInputEnvelope
    set?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    disconnect?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    delete?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    connect?: TranscriptChunkWhereUniqueInput | TranscriptChunkWhereUniqueInput[]
    update?: TranscriptChunkUpdateWithWhereUniqueWithoutMeetingInput | TranscriptChunkUpdateWithWhereUniqueWithoutMeetingInput[]
    updateMany?: TranscriptChunkUpdateManyWithWhereWithoutMeetingInput | TranscriptChunkUpdateManyWithWhereWithoutMeetingInput[]
    deleteMany?: TranscriptChunkScalarWhereInput | TranscriptChunkScalarWhereInput[]
  }

  export type MeetingCreateNestedOneWithoutTranscriptChunkInput = {
    create?: XOR<MeetingCreateWithoutTranscriptChunkInput, MeetingUncheckedCreateWithoutTranscriptChunkInput>
    connectOrCreate?: MeetingCreateOrConnectWithoutTranscriptChunkInput
    connect?: MeetingWhereUniqueInput
  }

  export type MeetingUpdateOneRequiredWithoutTranscriptChunkNestedInput = {
    create?: XOR<MeetingCreateWithoutTranscriptChunkInput, MeetingUncheckedCreateWithoutTranscriptChunkInput>
    connectOrCreate?: MeetingCreateOrConnectWithoutTranscriptChunkInput
    upsert?: MeetingUpsertWithoutTranscriptChunkInput
    connect?: MeetingWhereUniqueInput
    update?: XOR<XOR<MeetingUpdateToOneWithWhereWithoutTranscriptChunkInput, MeetingUpdateWithoutTranscriptChunkInput>, MeetingUncheckedUpdateWithoutTranscriptChunkInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type MeetingCreateWithoutUserInput = {
    id?: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    TranscriptChunk?: TranscriptChunkCreateNestedManyWithoutMeetingInput
  }

  export type MeetingUncheckedCreateWithoutUserInput = {
    id?: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    TranscriptChunk?: TranscriptChunkUncheckedCreateNestedManyWithoutMeetingInput
  }

  export type MeetingCreateOrConnectWithoutUserInput = {
    where: MeetingWhereUniqueInput
    create: XOR<MeetingCreateWithoutUserInput, MeetingUncheckedCreateWithoutUserInput>
  }

  export type MeetingCreateManyUserInputEnvelope = {
    data: MeetingCreateManyUserInput | MeetingCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type MeetingUpsertWithWhereUniqueWithoutUserInput = {
    where: MeetingWhereUniqueInput
    update: XOR<MeetingUpdateWithoutUserInput, MeetingUncheckedUpdateWithoutUserInput>
    create: XOR<MeetingCreateWithoutUserInput, MeetingUncheckedCreateWithoutUserInput>
  }

  export type MeetingUpdateWithWhereUniqueWithoutUserInput = {
    where: MeetingWhereUniqueInput
    data: XOR<MeetingUpdateWithoutUserInput, MeetingUncheckedUpdateWithoutUserInput>
  }

  export type MeetingUpdateManyWithWhereWithoutUserInput = {
    where: MeetingScalarWhereInput
    data: XOR<MeetingUpdateManyMutationInput, MeetingUncheckedUpdateManyWithoutUserInput>
  }

  export type MeetingScalarWhereInput = {
    AND?: MeetingScalarWhereInput | MeetingScalarWhereInput[]
    OR?: MeetingScalarWhereInput[]
    NOT?: MeetingScalarWhereInput | MeetingScalarWhereInput[]
    id?: StringFilter<"Meeting"> | string
    userId?: StringFilter<"Meeting"> | string
    title?: StringFilter<"Meeting"> | string
    description?: StringNullableFilter<"Meeting"> | string | null
    meetingUrl?: StringNullableFilter<"Meeting"> | string | null
    startTime?: DateTimeFilter<"Meeting"> | Date | string
    endTime?: DateTimeFilter<"Meeting"> | Date | string
    attendees?: JsonNullableFilter<"Meeting">
    calendarEventId?: StringNullableFilter<"Meeting"> | string | null
    isFromCalendar?: BoolFilter<"Meeting"> | boolean
    botScheduled?: BoolFilter<"Meeting"> | boolean
    botSent?: BoolFilter<"Meeting"> | boolean
    botId?: StringNullableFilter<"Meeting"> | string | null
    botJoinedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    meetingEnded?: BoolFilter<"Meeting"> | boolean
    transcriptReady?: BoolFilter<"Meeting"> | boolean
    transcript?: JsonNullableFilter<"Meeting">
    recordingUrl?: StringNullableFilter<"Meeting"> | string | null
    speakers?: JsonNullableFilter<"Meeting">
    summary?: StringNullableFilter<"Meeting"> | string | null
    actionItems?: JsonNullableFilter<"Meeting">
    processed?: BoolFilter<"Meeting"> | boolean
    processedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    emailSent?: BoolFilter<"Meeting"> | boolean
    emailSentAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    ragProcessed?: BoolFilter<"Meeting"> | boolean
    ragProcessedAt?: DateTimeNullableFilter<"Meeting"> | Date | string | null
    createdAt?: DateTimeFilter<"Meeting"> | Date | string
    updatedAt?: DateTimeFilter<"Meeting"> | Date | string
  }

  export type UserCreateWithoutMeetingsInput = {
    id: string
    clerkId: string
    email?: string | null
    name?: string | null
    botName?: string | null
    botImageUrl?: string | null
    googleAccessToken?: string | null
    googleRefreshToken?: string | null
    googleTokenExpiry?: Date | string | null
    calendarConnected?: boolean
    slackUserId?: string | null
    slackTeamId?: string | null
    slackConnected?: boolean
    preferredChannelId?: string | null
    preferredChannelName?: string | null
    currentPlan?: string
    subscriptionStatus?: string
    stripeCustomerId?: string | null
    stripeSubscriptionId?: string | null
    billingPeriodStart?: Date | string | null
    meetingsThisMonth?: number
    chatMessagesToday?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserUncheckedCreateWithoutMeetingsInput = {
    id: string
    clerkId: string
    email?: string | null
    name?: string | null
    botName?: string | null
    botImageUrl?: string | null
    googleAccessToken?: string | null
    googleRefreshToken?: string | null
    googleTokenExpiry?: Date | string | null
    calendarConnected?: boolean
    slackUserId?: string | null
    slackTeamId?: string | null
    slackConnected?: boolean
    preferredChannelId?: string | null
    preferredChannelName?: string | null
    currentPlan?: string
    subscriptionStatus?: string
    stripeCustomerId?: string | null
    stripeSubscriptionId?: string | null
    billingPeriodStart?: Date | string | null
    meetingsThisMonth?: number
    chatMessagesToday?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserCreateOrConnectWithoutMeetingsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutMeetingsInput, UserUncheckedCreateWithoutMeetingsInput>
  }

  export type TranscriptChunkCreateWithoutMeetingInput = {
    id?: string
    chunkIndex: number
    content: string
    speakerName?: string | null
    vectorId?: string | null
    createdAt?: Date | string
  }

  export type TranscriptChunkUncheckedCreateWithoutMeetingInput = {
    id?: string
    chunkIndex: number
    content: string
    speakerName?: string | null
    vectorId?: string | null
    createdAt?: Date | string
  }

  export type TranscriptChunkCreateOrConnectWithoutMeetingInput = {
    where: TranscriptChunkWhereUniqueInput
    create: XOR<TranscriptChunkCreateWithoutMeetingInput, TranscriptChunkUncheckedCreateWithoutMeetingInput>
  }

  export type TranscriptChunkCreateManyMeetingInputEnvelope = {
    data: TranscriptChunkCreateManyMeetingInput | TranscriptChunkCreateManyMeetingInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutMeetingsInput = {
    update: XOR<UserUpdateWithoutMeetingsInput, UserUncheckedUpdateWithoutMeetingsInput>
    create: XOR<UserCreateWithoutMeetingsInput, UserUncheckedCreateWithoutMeetingsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutMeetingsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutMeetingsInput, UserUncheckedUpdateWithoutMeetingsInput>
  }

  export type UserUpdateWithoutMeetingsInput = {
    id?: StringFieldUpdateOperationsInput | string
    clerkId?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    botName?: NullableStringFieldUpdateOperationsInput | string | null
    botImageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    googleAccessToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleRefreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleTokenExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    calendarConnected?: BoolFieldUpdateOperationsInput | boolean
    slackUserId?: NullableStringFieldUpdateOperationsInput | string | null
    slackTeamId?: NullableStringFieldUpdateOperationsInput | string | null
    slackConnected?: BoolFieldUpdateOperationsInput | boolean
    preferredChannelId?: NullableStringFieldUpdateOperationsInput | string | null
    preferredChannelName?: NullableStringFieldUpdateOperationsInput | string | null
    currentPlan?: StringFieldUpdateOperationsInput | string
    subscriptionStatus?: StringFieldUpdateOperationsInput | string
    stripeCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    stripeSubscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    billingPeriodStart?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingsThisMonth?: IntFieldUpdateOperationsInput | number
    chatMessagesToday?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateWithoutMeetingsInput = {
    id?: StringFieldUpdateOperationsInput | string
    clerkId?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    name?: NullableStringFieldUpdateOperationsInput | string | null
    botName?: NullableStringFieldUpdateOperationsInput | string | null
    botImageUrl?: NullableStringFieldUpdateOperationsInput | string | null
    googleAccessToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleRefreshToken?: NullableStringFieldUpdateOperationsInput | string | null
    googleTokenExpiry?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    calendarConnected?: BoolFieldUpdateOperationsInput | boolean
    slackUserId?: NullableStringFieldUpdateOperationsInput | string | null
    slackTeamId?: NullableStringFieldUpdateOperationsInput | string | null
    slackConnected?: BoolFieldUpdateOperationsInput | boolean
    preferredChannelId?: NullableStringFieldUpdateOperationsInput | string | null
    preferredChannelName?: NullableStringFieldUpdateOperationsInput | string | null
    currentPlan?: StringFieldUpdateOperationsInput | string
    subscriptionStatus?: StringFieldUpdateOperationsInput | string
    stripeCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    stripeSubscriptionId?: NullableStringFieldUpdateOperationsInput | string | null
    billingPeriodStart?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingsThisMonth?: IntFieldUpdateOperationsInput | number
    chatMessagesToday?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TranscriptChunkUpsertWithWhereUniqueWithoutMeetingInput = {
    where: TranscriptChunkWhereUniqueInput
    update: XOR<TranscriptChunkUpdateWithoutMeetingInput, TranscriptChunkUncheckedUpdateWithoutMeetingInput>
    create: XOR<TranscriptChunkCreateWithoutMeetingInput, TranscriptChunkUncheckedCreateWithoutMeetingInput>
  }

  export type TranscriptChunkUpdateWithWhereUniqueWithoutMeetingInput = {
    where: TranscriptChunkWhereUniqueInput
    data: XOR<TranscriptChunkUpdateWithoutMeetingInput, TranscriptChunkUncheckedUpdateWithoutMeetingInput>
  }

  export type TranscriptChunkUpdateManyWithWhereWithoutMeetingInput = {
    where: TranscriptChunkScalarWhereInput
    data: XOR<TranscriptChunkUpdateManyMutationInput, TranscriptChunkUncheckedUpdateManyWithoutMeetingInput>
  }

  export type TranscriptChunkScalarWhereInput = {
    AND?: TranscriptChunkScalarWhereInput | TranscriptChunkScalarWhereInput[]
    OR?: TranscriptChunkScalarWhereInput[]
    NOT?: TranscriptChunkScalarWhereInput | TranscriptChunkScalarWhereInput[]
    id?: StringFilter<"TranscriptChunk"> | string
    meetingId?: StringFilter<"TranscriptChunk"> | string
    chunkIndex?: IntFilter<"TranscriptChunk"> | number
    content?: StringFilter<"TranscriptChunk"> | string
    speakerName?: StringNullableFilter<"TranscriptChunk"> | string | null
    vectorId?: StringNullableFilter<"TranscriptChunk"> | string | null
    createdAt?: DateTimeFilter<"TranscriptChunk"> | Date | string
  }

  export type MeetingCreateWithoutTranscriptChunkInput = {
    id?: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutMeetingsInput
  }

  export type MeetingUncheckedCreateWithoutTranscriptChunkInput = {
    id?: string
    userId: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MeetingCreateOrConnectWithoutTranscriptChunkInput = {
    where: MeetingWhereUniqueInput
    create: XOR<MeetingCreateWithoutTranscriptChunkInput, MeetingUncheckedCreateWithoutTranscriptChunkInput>
  }

  export type MeetingUpsertWithoutTranscriptChunkInput = {
    update: XOR<MeetingUpdateWithoutTranscriptChunkInput, MeetingUncheckedUpdateWithoutTranscriptChunkInput>
    create: XOR<MeetingCreateWithoutTranscriptChunkInput, MeetingUncheckedCreateWithoutTranscriptChunkInput>
    where?: MeetingWhereInput
  }

  export type MeetingUpdateToOneWithWhereWithoutTranscriptChunkInput = {
    where?: MeetingWhereInput
    data: XOR<MeetingUpdateWithoutTranscriptChunkInput, MeetingUncheckedUpdateWithoutTranscriptChunkInput>
  }

  export type MeetingUpdateWithoutTranscriptChunkInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutMeetingsNestedInput
  }

  export type MeetingUncheckedUpdateWithoutTranscriptChunkInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MeetingCreateManyUserInput = {
    id?: string
    title: string
    description?: string | null
    meetingUrl?: string | null
    startTime: Date | string
    endTime: Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: string | null
    isFromCalendar?: boolean
    botScheduled?: boolean
    botSent?: boolean
    botId?: string | null
    botJoinedAt?: Date | string | null
    meetingEnded?: boolean
    transcriptReady?: boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: boolean
    processedAt?: Date | string | null
    emailSent?: boolean
    emailSentAt?: Date | string | null
    ragProcessed?: boolean
    ragProcessedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MeetingUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TranscriptChunk?: TranscriptChunkUpdateManyWithoutMeetingNestedInput
  }

  export type MeetingUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TranscriptChunk?: TranscriptChunkUncheckedUpdateManyWithoutMeetingNestedInput
  }

  export type MeetingUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    title?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    meetingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: DateTimeFieldUpdateOperationsInput | Date | string
    attendees?: NullableJsonNullValueInput | InputJsonValue
    calendarEventId?: NullableStringFieldUpdateOperationsInput | string | null
    isFromCalendar?: BoolFieldUpdateOperationsInput | boolean
    botScheduled?: BoolFieldUpdateOperationsInput | boolean
    botSent?: BoolFieldUpdateOperationsInput | boolean
    botId?: NullableStringFieldUpdateOperationsInput | string | null
    botJoinedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    meetingEnded?: BoolFieldUpdateOperationsInput | boolean
    transcriptReady?: BoolFieldUpdateOperationsInput | boolean
    transcript?: NullableJsonNullValueInput | InputJsonValue
    recordingUrl?: NullableStringFieldUpdateOperationsInput | string | null
    speakers?: NullableJsonNullValueInput | InputJsonValue
    summary?: NullableStringFieldUpdateOperationsInput | string | null
    actionItems?: NullableJsonNullValueInput | InputJsonValue
    processed?: BoolFieldUpdateOperationsInput | boolean
    processedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    emailSent?: BoolFieldUpdateOperationsInput | boolean
    emailSentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    ragProcessed?: BoolFieldUpdateOperationsInput | boolean
    ragProcessedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TranscriptChunkCreateManyMeetingInput = {
    id?: string
    chunkIndex: number
    content: string
    speakerName?: string | null
    vectorId?: string | null
    createdAt?: Date | string
  }

  export type TranscriptChunkUpdateWithoutMeetingInput = {
    id?: StringFieldUpdateOperationsInput | string
    chunkIndex?: IntFieldUpdateOperationsInput | number
    content?: StringFieldUpdateOperationsInput | string
    speakerName?: NullableStringFieldUpdateOperationsInput | string | null
    vectorId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TranscriptChunkUncheckedUpdateWithoutMeetingInput = {
    id?: StringFieldUpdateOperationsInput | string
    chunkIndex?: IntFieldUpdateOperationsInput | number
    content?: StringFieldUpdateOperationsInput | string
    speakerName?: NullableStringFieldUpdateOperationsInput | string | null
    vectorId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TranscriptChunkUncheckedUpdateManyWithoutMeetingInput = {
    id?: StringFieldUpdateOperationsInput | string
    chunkIndex?: IntFieldUpdateOperationsInput | number
    content?: StringFieldUpdateOperationsInput | string
    speakerName?: NullableStringFieldUpdateOperationsInput | string | null
    vectorId?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}